import 'dart:async';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart' show compute;
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'io.dart';
import 'models.dart';
import 'piano_roll.dart';
import 'settings.dart';
import 'synth.dart';
import 'theme.dart';

class EditorPage extends StatefulWidget {
  final XNProject project;
  const EditorPage({super.key, required this.project});
  @override State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  String _tool = 'draw';
  int _snapDiv = 4;
  XNNote? _sel;
  int _playTick = 0;
  bool _playing = false, _rendering = false, _dirty = true;
  Uint8List? _wav;
  final AudioPlayer _player = AudioPlayer();
  StreamSubscription? _sub;
  Timer? _saveDebounce;
  late final TextEditingController _lyricCtl = TextEditingController();

  XNProject get p => widget.project;

  @override
  void dispose() {
    _saveDebounce?.cancel();
    _sub?.cancel();
    _player.dispose();
    saveProject(p); // 离开时自动保存
    super.dispose();
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating));
  }

  void _changed() {
    _dirty = true;
    if (mounted) setState(() {});
    _saveDebounce?.cancel();
    _saveDebounce = Timer(const Duration(milliseconds: 900), () {
      saveProject(p);
    });
  }

  // ---------------- 播放 ----------------
  Future<void> _render() async {
    setState(() => _rendering = true);
    try {
      final wav = await compute(renderProjectIsolate, p.toJson());
      _wav = wav;
      _dirty = false;
    } catch (e) {
      _toast('渲染失败：$e');
    }
    if (mounted) setState(() => _rendering = false);
  }

  Future<void> _togglePlay() async {
    if (_playing) {
      await _sub?.cancel();
      _sub = null;
      await _player.stop();
      if (mounted) setState(() { _playing = false; _playTick = 0; });
      return;
    }
    if (_dirty || _wav == null) await _render();
    if (_wav == null) return;
    try {
      await _player.setAudioSource(BytesSource(_wav!, mimeType: 'audio/wav'));
      await _player.play();
      if (mounted) setState(() => _playing = true);
      _sub = _player.positionStream.listen((d) {
        final tk = p.tempo.secToTick(d.inMilliseconds / 1000.0);
        if (mounted && (tk - _playTick).abs() > 40) setState(() => _playTick = tk);
      });
      _sub = _player.playerStateStream.listen((s) {
        if (s.processingState == ProcessingState.completed && mounted) {
          setState(() { _playing = false; _playTick = 0; });
        }
      });
    } catch (e) {
      _toast('播放失败：$e');
    }
  }

  // ---------------- 菜单 ----------------
  Future<void> _menu(String v) async {
    switch (v) {
      case 'save':
        final path = await saveProject(p);
        _toast('已保存：$path');
        break;
      case 'import':
        await _importInto();
        break;
      case 'export_xilin':
        final path = await saveProject(p);
        _toast('已导出 .xilin：$path');
        break;
      case 'export_wav':
        await _exportWav();
        break;
    }
  }

  Future<void> _importInto() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.any);
    final path = res?.files.single.path;
    if (path == null) return;
    final np = await loadAny(path);
    if (np == null) { _toast('导入失败'); return; }
    if (!mounted) return;
    Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => EditorPage(project: np)));
  }

  Future<void> _exportWav() async {
    if (_dirty || _wav == null) await _render();
    if (_wav == null) return;
    try {
      final path = await writeFileToWorkspace('${p.name}_export.wav', _wav!);
      _toast('已导出 WAV：$path');
    } catch (e) {
      _toast('导出失败：$e');
    }
  }

  // ---------------- 速度/拍号 ----------------
  Future<void> _editTempo() async {
    final th = currentTheme;
    final segs = p.tempo.segs;
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: th.surface,
        title: Text('速度与拍号（支持中途变更）', style: TextStyle(color: th.text, fontSize: 17)),
        content: SizedBox(
          width: 440,
          child: ListView(shrinkWrap: true, children: [
            Text('位置 = tick（480 = 1 拍）。修改后重新打开本窗口可刷新显示。',
                style: TextStyle(color: th.dim, fontSize: 11)),
            const SizedBox(height: 8),
            for (int i = 0; i < segs.length; i++) _tempoRow(i, ctx),
            TextButton.icon(
              onPressed: () {
                segs.add(TempoSeg(tick: p.maxTick() + TempoMap.tpq, bpm: 120, beatsPerBar: 4, beatTicks: TempoMap.tpq));
                (ctx as Element).markNeedsBuild();
              },
              icon: const Icon(Icons.add),
              label: const Text('在此之后添加速度/拍号变更'),
            ),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('完成')),
        ],
      ),
    );
    p.tempo.normalize();
    _changed();
  }

  Widget _tempoRow(int i, BuildContext ctx) {
    final s = p.tempo.segs[i];
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(children: [
        _numField('位置tick', s.tick, (v) => s.tick = v.round(), enabled: i > 0, width: 110),
        const SizedBox(width: 6),
        _numField('BPM', s.bpm, (v) => s.bpm = v, width: 84),
        const SizedBox(width: 6),
        _numField('拍/小节', s.beatsPerBar.toDouble(), (v) => s.beatsPerBar = v.round(), width: 80),
        if (i > 0)
          IconButton(
            icon: const Icon(Icons.close, size: 18),
            onPressed: () {
              p.tempo.segs.removeAt(i);
              (ctx as Element).markNeedsBuild();
            },
          ),
      ]),
    );
  }

  Widget _numField(String label, double value, ValueChanged<double> onV,
      {bool enabled = true, double width = 90}) {
    final th = currentTheme;
    return SizedBox(
      width: width,
      child: TextFormField(
        enabled: enabled,
        initialValue: value % 1 == 0 ? value.toStringAsFixed(0) : value.toStringAsFixed(2),
        keyboardType: TextInputType.number,
        style: TextStyle(color: th.text, fontSize: 13),
        decoration: InputDecoration(labelText: label, isDense: true,
            labelStyle: TextStyle(color: th.dim, fontSize: 11)),
        onChanged: (t) {
          final v = double.tryParse(t);
          if (v != null) onV(v);
        },
      ),
    );
  }

  // ---------------- 音符属性 ----------------
  void _openNoteSheet() {
    final n = _sel;
    if (n == null) return;
    showModalBottomSheet(
      context: context,
      builder: (ctx) => StatefulBuilder(builder: (ctx, setS) {
        final th = currentTheme;
        return Container(
          color: th.surface,
          padding: EdgeInsets.only(
              left: 18, right: 18, top: 14,
              bottom: MediaQuery.of(ctx).viewInsets.bottom + 20),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('音符属性', style: TextStyle(color: th.text, fontWeight: FontWeight.w800)),
            const SizedBox(height: 6),
            _slider(setS, '颤音深度', n.vibratoDepth, (v) => n.vibratoDepth = v),
            _slider(setS, '颤音速度', n.vibratoRate / 10, (v) => n.vibratoRate = v * 10),
            _slider(setS, '亮度', n.brightness, (v) => n.brightness = v),
            _slider(setS, '气息', n.breathiness, (v) => n.breathiness = v),
            _slider(setS, '辅音速度', n.velocity, (v) => n.velocity = v),
            _slider(setS, '音量', n.volume, (v) => n.volume = v),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              IconButton(onPressed: () { setS(() => n.length = (n.length * 3 ~/ 2)); _changed(); },
                  icon: const Icon(Icons.expand), color: th.text),
              Text('${n.length} ticks', style: TextStyle(color: th.dim)),
              IconButton(onPressed: () { setS(() { final v = n.length * 2 ~/ 3; n.length = v < 60 ? 60 : v; }); _changed(); },
                  icon: const Icon(Icons.compress), color: th.text),
            ]),
          ]),
        );
      }),
    );
  }

  Widget _slider(void Function(void Function()) setS, String label, double v, ValueChanged<double> onV) {
    final th = currentTheme;
    return Row(children: [
      SizedBox(width: 86, child: Text(label, style: TextStyle(color: th.text, fontSize: 12))),
      Expanded(child: Slider(
        value: v.clamp(0.0, 1.0),
        activeColor: th.primary,
        onChanged: (x) {
          onV(x);
          setS(() {});
          _changed();
        },
      )),
    ]);
  }

  void _splitSelected() {
    final n = _sel;
    if (n == null) return;
    for (final t in p.tracks) {
      if (t.notes.contains(n)) {
        if (n.length >= 120) {
          t.notes.add(n.split(n.start + n.length ~/ 2));
          _changed();
        }
        return;
      }
    }
  }

  void _deleteSelected() {
    final n = _sel;
    if (n == null) return;
    for (final t in p.tracks) {
      if (t.notes.remove(n)) break;
    }
    _lyricCtl.clear();
    setState(() => _sel = null);
    _changed();
  }

  // ---------------- UI ----------------
  @override
  Widget build(BuildContext context) {
    final th = currentTheme;
    return Scaffold(
      backgroundColor: th.bg,
      appBar: AppBar(
        backgroundColor: th.surface,
        foregroundColor: th.text,
        title: Text(p.name, style: TextStyle(color: th.text, fontSize: 16, fontWeight: FontWeight.w700)),
        actions: [
          InkWell(
            onTap: _editTempo,
            borderRadius: BorderRadius.circular(8),
            child: Container(
              margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 8),
              padding: const EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                  color: th.primary.withAlpha(30), borderRadius: BorderRadius.circular(8)),
              child: Center(child: Text(
                  '${_bpmStr(p.tempo.segs.first.bpm)} • ${p.tempo.segs.first.beatsPerBar}/4',
                  style: TextStyle(color: th.primary, fontWeight: FontWeight.w700, fontSize: 13))),
            ),
          ),
          IconButton(onPressed: () => showSettingsSheet(context, p, onChanged: _changed),
              icon: const Icon(Icons.palette_outlined)),
          PopupMenuButton<String>(
            onSelected: _menu,
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'save', child: Text('保存工程')),
              PopupMenuItem(value: 'import', child: Text('导入工程 (xilin/ustx/midi)')),
              PopupMenuItem(value: 'export_xilin', child: Text('导出 .xilin')),
              PopupMenuItem(value: 'export_wav', child: Text('导出 .wav')),
            ],
          ),
        ],
      ),
      body: Column(children: [
        _toolbar(th),
        Divider(height: 1, color: th.gridSub),
        Expanded(child: PianoRoll(
          project: p, tool: _tool,
          selectedId: _sel?.id, playTick: _playTick,
          snapDiv: _snapDiv,
          onChanged: _changed,
          onNoteSelected: (n) {
            setState(() {
              _sel = n;
              if (n != null) _lyricCtl.text = n.lyric;
            });
          },
        )),
        if (_sel != null) _propsBar(th),
      ]),
    );
  }

  String _bpmStr(double b) => b % 1 == 0 ? b.toStringAsFixed(0) : b.toStringAsFixed(2);

  Widget _toolbar(XNTheme th) {
    return Container(
      color: th.surface,
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      child: Row(children: [
        _toolBtn(th, 'select', Icons.touch_app, '选择'),
        _toolBtn(th, 'draw', Icons.edit, '绘制'),
        _toolBtn(th, 'split', Icons.content_cut, '分片'),
        _toolBtn(th, 'delete', Icons.delete_outline, '删除'),
        const SizedBox(width: 4),
        DropdownButton<int>(
          value: _snapDiv,
          underline: const SizedBox(),
          dropdownColor: th.surface,
          style: TextStyle(color: th.text, fontSize: 12),
          items: const [
            DropdownMenuItem(value: 1, child: Text('1/4')),
            DropdownMenuItem(value: 2, child: Text('1/8')),
            DropdownMenuItem(value: 4, child: Text('1/16')),
            DropdownMenuItem(value: 8, child: Text('1/32')),
          ],
          onChanged: (v) => setState(() => _snapDiv = v!),
        ),
        const Spacer(),
        if (_rendering) SizedBox(width: 20, height: 20,
            child: CircularProgressIndicator(strokeWidth: 2, color: th.primary)),
        const SizedBox(width: 6),
        IconButton.filledTonal(
          onPressed: _togglePlay,
          style: IconButton.styleFrom(backgroundColor: th.primary.withAlpha(50)),
          icon: _playing
              ? Icon(Icons.stop, size: 26, color: th.primary)
              : Icon(Icons.play_arrow, size: 26, color: th.primary),
        ),
      ]),
    );
  }

  Widget _toolBtn(XNTheme th, String tool, IconData icon, String tip) {
    final active = _tool == tool;
    return Tooltip(
      message: tip,
      child: IconButton(
        onPressed: () => setState(() => _tool = tool),
        icon: Icon(icon, size: 20),
        color: active ? th.primary : th.dim,
        style: IconButton.styleFrom(
          backgroundColor: active ? th.primary.withAlpha(40) : null,
        ),
      ),
    );
  }

  Widget _propsBar(XNTheme th) {
    final n = _sel!;
    return Container(
      color: th.surface,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      child: Row(children: [
        SizedBox(
          width: 110,
          child: TextField(
            key: ValueKey('lyr${n.id}'),
            controller: _lyricCtl,
            style: TextStyle(color: th.text, fontSize: 14),
            decoration: const InputDecoration(
                isDense: true, hintText: '歌词', border: OutlineInputBorder()),
            onChanged: (v) { n.lyric = v; _changed(); },
          ),
        ),
        IconButton(onPressed: _openNoteSheet, icon: const Icon(Icons.tune), color: th.primary),
        IconButton(onPressed: _splitSelected, icon: const Icon(Icons.content_cut), color: th.text),
        IconButton(onPressed: _deleteSelected, icon: const Icon(Icons.delete_outline), color: th.text),
        const Spacer(),
        Text('MIDI ${n.pitch} • ${n.start}',
            style: TextStyle(color: th.dim, fontSize: 11)),
      ]),
    );
  }
}