import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'models.dart';
import 'theme.dart';
import 'voicebank.dart';

Future<void> showSettingsSheet(BuildContext context, XNProject project,
    {required VoidCallback onChanged}) {
  return showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
    builder: (_) => _SettingsSheet(project: project, onChanged: onChanged),
  );
}

class _SettingsSheet extends StatefulWidget {
  final XNProject project;
  final VoidCallback onChanged;
  const _SettingsSheet({required this.project, required this.onChanged});
  @override State<_SettingsSheet> createState() => _SettingsSheetState();
}

class _SettingsSheetState extends State<_SettingsSheet> {
  XNProject get p => widget.project;
  String _bankMsg = '';

  void _pickBank() async {
    final path = await FilePicker.platform
        .getDirectoryPath(dialogTitle: '选择 UTAU 声库目录（含 oto.ini）');
    if (path == null) return;
    if (!UtauVoicebank.looksLikeVoicebank(path)) {
      setState(() => _bankMsg = '未在该目录找到 oto.ini，已忽略');
      return;
    }
    p.bankPath = path;
    final vb = UtauVoicebank.loadSync(path);
    setState(() {
      _bankMsg = '已加载：${(vb?.name.isNotEmpty ?? false) ? vb!.name : '未命名声库'}';
    });
    widget.onChanged();
  }

  Widget _group(String title) {
    final th = currentTheme;
    return Padding(
      padding: const EdgeInsets.only(top: 16, bottom: 6),
      child: Text(title, style: TextStyle(color: th.primary, fontWeight: FontWeight.w800, fontSize: 13)),
    );
  }

  Widget _slider(String label, double v, ValueChanged<double> onV, {double min = 0, double max = 1}) {
    final th = currentTheme;
    return Row(children: [
      SizedBox(width: 110, child: Text(label, style: TextStyle(color: th.text, fontSize: 12))),
      Expanded(child: Slider(
        value: v.clamp(min, max),
        min: min, max: max,
        activeColor: th.primary,
        onChanged: (x) { onV(x); setState(() {}); widget.onChanged(); },
      )),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final th = currentTheme;
    return Container(
      height: MediaQuery.of(context).size.height * 0.84,
      color: th.bg,
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 14, 18, 30),
        children: [
          Center(child: Text('设置', style: TextStyle(color: th.text, fontSize: 17, fontWeight: FontWeight.w900))),
          _group('界面主题'),
          GridView.count(
            crossAxisCount: 4,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            childAspectRatio: 1.1,
            mainAxisSpacing: 8, crossAxisSpacing: 8,
            children: [
              for (int i = 0; i < xnThemes.length; i++)
                _themeCard(i, xnThemes[i]),
            ],
          ),
          _group('UTAU 声库'),
          Text(p.bankPath == null || p.bankPath!.isEmpty
                  ? '当前：内置合成音色'
                  : '当前：$p.bankPath'.replaceFirst('当前：Project', '当前：'),
              style: TextStyle(color: th.dim, fontSize: 12)),
          if (_bankMsg.isNotEmpty)
            Text(_bankMsg, style: TextStyle(color: th.accent, fontSize: 12)),
          const SizedBox(height: 8),
          Row(children: [
            FilledButton.icon(onPressed: _pickBank, icon: const Icon(Icons.folder_open, size: 18), label: const Text('选择声库目录')),
            const SizedBox(width: 10),
            OutlinedButton(
              onPressed: () { p.bankPath = null; setState(() => _bankMsg = '已切换回内置音色'); widget.onChanged(); },
              child: const Text('清除'),
            ),
          ]),
          _group('音色（全局）'),
          _slider('音色/性别感', p.voiceScale, (v) => p.voiceScale = v, min: 0.8, max: 1.25),
          _group('新音符默认参数'),
          _slider('亮度', p.defBrightness, (v) => p.defBrightness = v),
          _slider('气息', p.defBreathiness, (v) => p.defBreathiness = v),
          _slider('颤音深度', p.defVibratoDepth, (v) => p.defVibratoDepth = v),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () {
              for (final t in p.tracks) {
                for (final n in t.notes) {
                  n.brightness = p.defBrightness;
                  n.breathiness = p.defBreathiness;
                  n.vibratoDepth = p.defVibratoDepth;
                  n.vibratoRate = p.defVibratoRate;
                }
              }
              widget.onChanged();
              if (mounted) setState(() {});
            },
            icon: const Icon(Icons.done_all, size: 18),
            label: const Text('将默认参数应用到全部音符'),
          ),
        ],
      ),
    );
  }

  Widget _themeCard(int i, XNTheme t) {
    final sel = themeNotifier.value == i;
    return GestureDetector(
      onTap: () { themeNotifier.value = i; setState(() {}); },
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: sel ? t.accent : Colors.transparent, width: 2),
        ),
        child: Column(children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(10)),
                gradient: LinearGradient(colors: [t.bg, t.primary]),
              ),
            ),
          ),
          Container(
            height: 22,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: t.surface,
              borderRadius: const BorderRadius.vertical(bottom: Radius.circular(10)),
            ),
            child: Text(t.name, style: TextStyle(color: t.text, fontSize: 10)),
          ),
        ]),
      ),
    );
  }
}