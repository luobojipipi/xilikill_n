import 'dart:math' as math;
import 'dart:ui';

int _idSeq = 0;
int genId() =>
    (DateTime.now().microsecondsSinceEpoch ~/ 1000 + (_idSeq++) * 7919) & 0x3FFFFFFF;

bool isBlackKey(int midi) {
  final p = midi % 12;
  return p == 1 || p == 3 || p == 6 || p == 8 || p == 10;
}

double midiHz(int m) => 440.0 * math.pow(2.0, (m - 69) / 12.0).toDouble();

double _d(dynamic v, double def) => v is num ? v.toDouble() : def;
int _i(dynamic v, int def) => v is num ? v.toInt() : def;
String _s(dynamic v, String def) => v == null ? def : v.toString();

class XNNote {
  int id;
  int pitch;   // MIDI 音高
  int start;   // 起始位置
  int length;  // 长度
  String lyric;
  double velocity;      // 0..1 辅音速度/力度
  double vibratoDepth;  // 0..1
  double vibratoRate;   // Hz
  double brightness;    // 0..1 音色亮度
  double breathiness;   // 0..1 气息
  double volume;

  XNNote({
    int? id,
    required this.pitch,
    required this.start,
    this.length = 480,
    this.lyric = 'a',
    this.velocity = 0.8,
    this.vibratoDepth = 0.4,
    this.vibratoRate = 5.5,
    this.brightness = 0.55,
    this.breathiness = 0.3,
    this.volume = 1.0,
  }) : id = id ?? genId();

  int get end => start + length;

  /// 分片：在 atTick 处切开，返回右半段
  XNNote split(int atTick) {
    final right = XNNote(
      pitch: pitch, start: atTick, length: end - atTick, lyric: lyric,
      velocity: velocity, vibratoDepth: vibratoDepth, vibratoRate: vibratoRate,
      brightness: brightness, breathiness: breathiness, volume: volume,
    );
    length = atTick - start;
    return right;
  }

  Map<String, dynamic> toJson() => {
        'id': id, 'pitch': pitch, 'start': start, 'length': length, 'lyric': lyric,
        'velocity': velocity, 'vibratoDepth': vibratoDepth, 'vibratoRate': vibratoRate,
        'brightness': brightness, 'breathiness': breathiness, 'volume': volume,
      };

  factory XNNote.fromJson(Map<String, dynamic> j) => XNNote(
        id: _i(j['id'], 0),
        pitch: _i(j['pitch'], 60), start: _i(j['start'], 0),
        length: _i(j['length'], 480), lyric: _s(j['lyric'], 'a'),
        velocity: _d(j['velocity'], 0.8), vibratoDepth: _d(j['vibratoDepth'], 0.4),
        vibratoRate: _d(j['vibratoRate'], 5.5), brightness: _d(j['brightness'], 0.55),
        breathiness: _d(j['breathiness'], 0.3), volume: _d(j['volume'], 1.0),
      );
}

class XNTrack {
  int id;
  String name;
  int colorValue;
  double volume;
  bool muted;
  List<XNNote> notes;

  XNTrack({
    int? id,
    this.name = 'Track',
    int? colorValue,
    this.volume = 1.0,
    this.muted = false,
    List<XNNote>? notes,
  })  : id = id ?? genId(),
        colorValue = colorValue ?? 0xFF4FC3F7,
        notes = notes ?? [];

  Color get color => Color(colorValue);

  Map<String, dynamic> toJson() => {
        'id': id, 'name': name, 'color': colorValue,
        'volume': volume, 'muted': muted,
        'notes': [for (final n in notes) n.toJson()],
      };

  factory XNTrack.fromJson(Map<String, dynamic> j) {
    final notes = <XNNote>[];
    if (j['notes'] is List) {
      for (final n in j['notes']) {
        if (n is Map) notes.add(XNNote.fromJson(Map<String, dynamic>.from(n)));
      }
    }
    return XNTrack(
      id: _i(j['id'], 0), name: _s(j['name'], 'Track'),
      colorValue: _i(j['color'], 0xFF4FC3F7), volume: _d(j['volume'], 1.0),
      muted: j['muted'] == true, notes: notes,
    );
  }
}

class TempoSeg {
  int tick;
  double bpm;
  int beatsPerBar;
  int beatTicks; // 一拍的 tick 数（支持 6/8 等拍号）
  TempoSeg({this.tick = 0, this.bpm = 120, this.beatsPerBar = 4, this.beatTicks = TempoMap.tpq});
}

class BarMark {
  final int tick;
  final int index;  // 小节号（0 起）
  final int beats;  // 该小节拍数
  const BarMark({required this.tick, required this.index, required this.beats});
}

class TempoMap {
  static const int tpq = 480;
  List<TempoSeg> segs;

  TempoMap([TempoSeg? first])
      : segs = [first ?? TempoSeg(tick: 0, bpm: 120, beatsPerBar: 4, beatTicks: tpq)];

  void normalize() {
    if (segs.isEmpty) {
      segs.add(TempoSeg(tick: 0, bpm: 120, beatsPerBar: 4, beatTicks: tpq));
    }
    segs.sort((a, b) => a.tick.compareTo(b.tick));
    if (segs.first.tick > 0) {
      segs.insert(0, TempoSeg(tick: 0, bpm: segs.first.bpm,
          beatsPerBar: segs.first.beatsPerBar, beatTicks: segs.first.beatTicks));
    }
    final out = <TempoSeg>[segs.first];
    for (int i = 1; i < segs.length; i++) {
      if (segs[i].tick > out.last.tick) out.add(segs[i]);
    }
    segs..clear()..addAll(out);
  }

  TempoSeg segAtTick(int t) {
    var s = segs.first;
    for (final e in segs) {
      if (e.tick <= t) { s = e; } else { break; }
    }
    return s;
  }

  double tickToSec(int tick) {
    double acc = 0;
    for (int i = 0; i < segs.length; i++) {
      final s = segs[i];
      final segEnd = i + 1 < segs.length ? segs[i + 1].tick : 2147483647;
      final eff = tick < segEnd ? tick : segEnd;
      if (eff > s.tick) acc += (eff - s.tick) * (60.0 / s.bpm) / s.beatTicks;
      if (tick <= segEnd) break;
    }
    return acc;
  }

  int secToTick(double sec) {
    double acc = 0;
    for (int i = 0; i < segs.length; i++) {
      final s = segs[i];
      final segEnd = i + 1 < segs.length ? segs[i + 1].tick : 2147483647;
      final spt = (60.0 / s.bpm) / s.beatTicks;
      final segSec = (segEnd - s.tick) * spt;
      if (sec < acc + segSec || i == segs.length - 1) {
        return s.tick + ((sec - acc) / spt).round();
      }
      acc += segSec;
    }
    return 0;
  }

  /// 生成小节标记（支持中途变拍；拍号变更点若在小节中间则截断该小节）
  List<BarMark> barMarksUntil(int untilTick) {
    final out = <BarMark>[];
    int curTick = 0, barIndex = 0, i = 0, guard = 0;
    while (curTick < untilTick && guard++ < 200000) {
      while (i + 1 < segs.length && segs[i + 1].tick <= curTick) i++;
      final seg = segs[i];
      final barLen = math.max(1, seg.beatsPerBar * seg.beatTicks);
      if (i + 1 < segs.length && curTick + barLen > segs[i + 1].tick) {
        final next = segs[i + 1].tick;
        final beats = ((next - curTick) / seg.beatTicks).ceil();
        out.add(BarMark(tick: curTick, index: barIndex, beats: math.max(1, beats)));
        curTick = next;
        barIndex++;
        continue;
      }
      out.add(BarMark(tick: curTick, index: barIndex, beats: seg.beatsPerBar));
      curTick += barLen;
      barIndex++;
    }
    return out;
  }
}

class XNProject {
  String name;
  TempoMap tempo;
  List<XNTrack> tracks;
  String? bankPath;          // UTAU 声库目录
  double voiceScale;         // 共振峰缩放（音色/性别感）
  double defBrightness, defBreathiness, defVibratoDepth, defVibratoRate;
  int snapDiv;

  XNProject({
    required this.name,
    TempoMap? tempo,
    List<XNTrack>? tracks,
    this.bankPath,
    this.voiceScale = 1.0,
    this.defBrightness = 0.55,
    this.defBreathiness = 0.3,
    this.defVibratoDepth = 0.4,
    this.defVibratoRate = 5.5,
    this.snapDiv = 4,
  })  : tempo = tempo ?? TempoMap(),
        tracks = tracks ?? [XNTrack(name: 'Vocal 1', colorValue: 0xFF4FC3F7)];

  int maxTick() {
    int m = 0;
    for (final t in tracks) {
      for (final n in t.notes) {
        if (n.end > m) m = n.end;
      }
    }
    return m;
  }

  Map<String, dynamic> toJson() => {
        'app': 'Xilikill N', 'version': 1, 'name': name, 'tpq': TempoMap.tpq,
        'tempo': {
          'segs': [
            for (final s in tempo.segs)
              {'tick': s.tick, 'bpm': s.bpm, 'beatsPerBar': s.beatsPerBar, 'beatTicks': s.beatTicks}
          ]
        },
        'bankPath': bankPath, 'voiceScale': voiceScale,
        'defBrightness': defBrightness, 'defBreathiness': defBreathiness,
        'defVibratoDepth': defVibratoDepth, 'defVibratoRate': defVibratoRate,
        'snapDiv': snapDiv,
        'tracks': [for (final t in tracks) t.toJson()],
      };

  factory XNProject.fromJson(Map<String, dynamic> j) {
    final tempo = TempoMap();
    final tj = j['tempo'];
    if (tj is Map && tj['segs'] is List) {
      tempo.segs.clear();
      for (final s in tj['segs']) {
        if (s is Map) {
          tempo.segs.add(TempoSeg(
            tick: _i(s['tick'], 0), bpm: _d(s['bpm'], 120),
            beatsPerBar: _i(s['beatsPerBar'], 4), beatTicks: _i(s['beatTicks'], TempoMap.tpq),
          ));
        }
      }
    }
    tempo.normalize();
    final tracks = <XNTrack>[];
    if (j['tracks'] is List) {
      for (final t in j['tracks']) {
        if (t is Map) tracks.add(XNTrack.fromJson(Map<String, dynamic>.from(t)));
      }
    }
    if (tracks.isEmpty) tracks.add(XNTrack(name: 'Vocal 1'));
    return XNProject(
      name: _s(j['name'], 'Untitled'), tempo: tempo, tracks: tracks,
      bankPath: j['bankPath']?.toString(),
      voiceScale: _d(j['voiceScale'], 1.0),
      defBrightness: _d(j['defBrightness'], 0.55),
      defBreathiness: _d(j['defBreathiness'], 0.3),
      defVibratoDepth: _d(j['defVibratoDepth'], 0.4),
      defVibratoRate: _d(j['defVibratoRate'], 5.5),
      snapDiv: _i(j['snapDiv'], 4),
    );
  }
}