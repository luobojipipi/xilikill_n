import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'midi_import.dart';
import 'models.dart';
import 'ustx_import.dart';

Future<Directory> _xnDir() async {
  final base = await getApplicationDocumentsDirectory();
  final dir = Directory('${base.path}${Platform.pathSeparator}XilikillN');
  if (!await dir.exists()) await dir.create(recursive: true);
  return dir;
}

String safeFileName(String s) => s.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_');

/// 保存 .xilin 工程
Future<String> saveProject(XNProject p) async {
  final dir = await _xnDir();
  final f = File('${dir.path}${Platform.pathSeparator}${safeFileName(p.name)}.xilin');
  await f.writeAsString(const JsonEncoder.withIndent('  ').convert(p.toJson()));
  return f.path;
}

/// 列出全部工程
Future<List<Map<String, dynamic>>> listProjects() async {
  final dir = await _xnDir();
  final out = <Map<String, dynamic>>[];
  try {
    await for (final e in dir.list()) {
      if (e is File && e.path.toLowerCase().endsWith('.xilin')) {
        final st = await e.stat();
        final name = e.uri.pathSegments.last
            .replaceAll(RegExp(r'\.xilin$', caseSensitive: false), '');
        out.add({'name': name, 'path': e.path, 'mtime': st.modified});
      }
    }
  } catch (_) {}
  out.sort((a, b) => (b['mtime'] as DateTime).compareTo(a['mtime'] as DateTime));
  return out;
}

Future<void> deleteProject(String path) async {
  final f = File(path);
  if (await f.exists()) await f.delete();
}

/// 写导出文件
Future<String> writeFileToWorkspace(String fileName, List<int> bytes) async {
  final dir = await _xnDir();
  final f = File('${dir.path}${Platform.pathSeparator}${safeFileName(fileName)}');
  await f.writeAsBytes(bytes);
  return f.path;
}

/// 按扩展名分发导入：.xilin / .ustx / .mid / .midi
Future<XNProject?> loadAny(String path) async {
  final lower = path.toLowerCase();
  try {
    if (lower.endsWith('.ustx')) {
      final base = path.split(Platform.pathSeparator).last;
      return UstxImport.parse(
          await File(path).readAsString(), base.replaceAll('.ustx', ''));
    }
    if (lower.endsWith('.mid') || lower.endsWith('.midi')) {
      final base = path.split(Platform.pathSeparator).last;
      return MidiImport.parse(
          await File(path).readAsBytes(),
          base.replaceAll(RegExp(r'\.midi?$', caseSensitive: false), ''));
    }
    final txt = await File(path).readAsString();
    return XNProject.fromJson(jsonDecode(txt) as Map<String, dynamic>);
  } catch (_) {
    return null;
  }
}