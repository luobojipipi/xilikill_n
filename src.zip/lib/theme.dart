import 'package:flutter/material.dart';

class XNTheme {
  final String name;
  final bool dark;
  final Color bg, bg2, surface, surfaceAlt, primary, accent, text, dim;
  final Color gridSub, gridBeat, gridBar, playhead;
  final Color keyWhite, keyBlack, rollWhiteRow, rollBlackRow;
  XNTheme({
    required this.name, required this.dark,
    required this.bg, required this.bg2, required this.surface, required this.surfaceAlt,
    required this.primary, required this.accent, required this.text, required this.dim,
    required this.gridSub, required this.gridBeat, required this.gridBar, required this.playhead,
    required this.keyWhite, required this.keyBlack,
    required this.rollWhiteRow, required this.rollBlackRow,
  });
}

XNTheme _mk(String name, bool dark, int bg, int surface, int primary, int accent) {
  final p = Color(primary);
  return XNTheme(
    name: name, dark: dark,
    bg: Color(bg), bg2: Color.lerp(Color(bg), p, 0.10)!,
    surface: Color(surface), surfaceAlt: Color.lerp(Color(surface), p, 0.08)!,
    primary: p, accent: Color(accent),
    text: dark ? const Color(0xFFEAF2FF) : const Color(0xFF182233),
    dim: dark ? const Color(0xFF8A96B0) : const Color(0xFF67718A),
    gridSub: p.withAlpha(28), gridBeat: p.withAlpha(70), gridBar: p.withAlpha(170),
    playhead: const Color(0xFFFF5252),
    keyWhite: dark ? const Color(0xFF2A3247) : const Color(0xFF3B4454),
    keyBlack: dark ? const Color(0xFF12161F) : const Color(0xFF1C222C),
    rollWhiteRow: dark ? const Color(0xFF161E30) : const Color(0xFFE9EDF4),
    rollBlackRow: dark ? const Color(0xFF101724) : const Color(0xFFDCE2EE),
  );
}

final List<XNTheme> xnThemes = [
  _mk('星夜蓝', true, 0xFF0B1020, 0xFF141C30, 0xFF4FC3F7, 0xFFB388FF),
  _mk('霓虹紫', true, 0xFF0E0716, 0xFF1A1026, 0xFFE040FB, 0xFF00E5FF),
  _mk('墨黑金', true, 0xFF0A0A0A, 0xFF161616, 0xFFFFD54F, 0xFFFF8A65),
  _mk('极昼', false, 0xFFF2F5FA, 0xFFFFFFFF, 0xFF1976D2, 0xFF00897B),
  _mk('樱粉', false, 0xFFFDF3F7, 0xFFFFFFFF, 0xFFEC407A, 0xFF7E57C2),
  _mk('苔原绿', true, 0xFF0B1410, 0xFF132019, 0xFF66BB6A, 0xFFFFCA28),
  _mk('深海', true, 0xFF041220, 0xFF0A1F33, 0xFF26C6DA, 0xFFFFB74D),
  _mk('落日', true, 0xFF160D0A, 0xFF241410, 0xFFFF7043, 0xFFFFD180),
];

/// 全局主题切换器（持久化在 main.dart 中完成）
final ValueNotifier<int> themeNotifier = ValueNotifier<int>(0);

XNTheme get currentTheme =>
    xnThemes[themeNotifier.value.clamp(0, xnThemes.length - 1)];