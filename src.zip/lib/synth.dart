import 'dart:math' as math;
import 'dart:typed_data';
import 'dsp.dart';
import 'models.dart';
import 'phonetics.dart';
import 'voicebank.dart';

const int _sr = 44100;

/// Xilikill N 歌声合成引擎（源-滤波模型，离线渲染）
///  - 声源：KLGLOTT88 多项式脉冲 + 差分
///  - 声道：4 阶共振峰带通级联 + 频谱倾斜低通
///  - 表现：滑音、颤音（延迟渐入）、随机音高漂移、气声、辅音噪声成形
class SynthRenderer {
  final math.Random _rng = math.Random();
  final List<double> _cur = [800, 1200, 2600, 3400];

  Uint8List render(XNProject proj) {
    UtauVoicebank? vb;
    if (proj.bankPath != null && proj.bankPath!.isNotEmpty) {
      vb = UtauVoicebank.loadSync(proj.bankPath!);
    }
    final maxT = proj.maxTick();
    final totalSec = (maxT <= 0 ? 1.0 : proj.tempo.tickToSec(maxT + 960)) + 1.2;
    final buf = Float32List((totalSec * _sr).ceil() + 1024);

    for (final tr in proj.tracks) {
      if (tr.muted) continue;
      final notes = [...tr.notes]..sort((a, b) => a.start.compareTo(b.start));
      int prevMidi = -1;
      double prevEnd = 0;
      for (final n in notes) {
        final s0 = proj.tempo.tickToSec(n.start);
        var dur = proj.tempo.tickToSec(n.start + n.length) - s0;
        if (dur < 0.1) dur = 0.1;
        _renderNote(buf, s0, dur, n, prevMidi, tr.volume, vb, proj);
        prevMidi = n.pitch;
        prevEnd = s0 + dur;
      }
    }
    _post(buf);
    return encodeWav16(buf, _sr);
  }

  void _renderNote(Float32List buf, double t0, double dur, XNNote note,
      int prevMidi, double trackVol, UtauVoicebank? vb, XNProject proj) {
    final i0 = (t0 * _sr).floor();
    if (i0 >= buf.length) return;
    final n = math.min(buf.length - i0, (dur * _sr).ceil());
    if (n <= 8) return;

    final ph = lyricToPhones(note.lyric.isEmpty ? 'a' : note.lyric);

    // ---------- 辅音时长 ----------
    final consDefs = <PhoneDef>[];
    final consLens = <double>[];
    double rawCons = 0;
    for (final c in ph.cons) {
      final d = phones[c];
      if (d == null || d.type == 'v') continue;
      consDefs.add(d);
      final l = d.lenMs / 1000.0 * (1.25 - 0.55 * dclamp(note.velocity, 0.0, 1.0));
      consLens.add(l);
      rawCons += l;
    }
    final consTotal = rawCons <= 0 ? 0.0 : math.min(rawCons, dur * 0.5);
    final consScale = rawCons > 0 ? consTotal / rawCons : 0.0;
    final vowelDur = math.max(dur - consTotal, 0.12);
    final frames = ph.frames.isEmpty
        ? const <MapEntry<double, String>>[MapEntry(0.0, 'a')]
        : ph.frames;

    // ---------- 音高 ----------
    final targetHz = midiHz(note.pitch);
    final startHz = prevMidi >= 0 ? midiHz(prevMidi) : targetHz;
    final portDur = math.min(0.07, dur * 0.3);
    final vibRate = note.vibratoRate <= 0 ? 5.5 : note.vibratoRate;
    final vibCents = note.vibratoDepth * 90.0;
    final vibPh = _rng.nextDouble() * 6.28318;
    final dph1 = _rng.nextDouble() * 6.28318;
    final dph2 = _rng.nextDouble() * 6.28318;

    // ---------- 滤波器与状态 ----------
    final bq = List.generate(4, (_) => Biquad());
    final nbq = Biquad();
    final tilt = Biquad();
    for (int i = 0; i < 4; i++) {
      _cur[i] = phones[frames.first.value]!.f[i];
    }
    double phase = _rng.nextDouble();
    double uPrev = 0;
    const bw = [80.0, 90.0, 120.0, 180.0];
    final fTgt = List<double>.filled(4, 0);
    final breath = 0.02 + 0.1 * dclamp(note.breathiness, 0.0, 1.0);
    final bright = dclamp(note.brightness, 0.0, 1.0);
    double tiltFc = 2000 + 6000 * bright;
    final fs = dclamp(proj.voiceScale, 0.7, 1.4);
    final gain = dclamp(note.volume, 0.0, 1.5) * dclamp(trackVol, 0.0, 1.5);

    int smp = 0;
    double tRel = 0;
    while (smp < n) {
      final chunk = math.min(64, n - smp);
      final tMid = tRel + chunk * 0.5 / _sr;

      // ---------- 块级声学参数 ----------
      double voiceAmt = 1, noiseAmt = 0, breathAmt = breath, env = 1;
      double nf = 2600, nbw = 2500;
      if (tMid < consTotal && consDefs.isNotEmpty) {
        double acc = 0;
        var d = consDefs.last;
        double lt = 1, cl = 1;
        for (int ci = 0; ci < consDefs.length; ci++) {
          cl = consLens[ci] * consScale;
          if (tMid < acc + cl) {
            d = consDefs[ci];
            lt = (tMid - acc) / math.max(1e-6, cl);
            break;
          }
          acc += cl;
        }
        for (int i = 0; i < 4; i++) { fTgt[i] = d.f[i]; }
        switch (d.type) {
          case 'stop':
          case 'aff':
            if (lt < d.sil) {
              voiceAmt = 0; noiseAmt = 0; breathAmt = 0;
            } else {
              voiceAmt = d.voice; noiseAmt = d.noise; nf = d.nf; nbw = d.nbw;
            }
            break;
          case 'fri':
            voiceAmt = d.voice; noiseAmt = d.noise; nf = d.nf; nbw = d.nbw;
            break;
          default: // nasal / liq / glide
            voiceAmt = 1; noiseAmt = 0.03;
            break;
        }
        env = (math.min(1.0, lt * cl / 0.01) * math.min(1.0, (1 - lt) * cl / 0.012));
        env = dclamp(env, 0.0, 1.0);
      } else {
        final pos = dclamp((tMid - consTotal) / vowelDur, 0.0, 1.0);
        _vowelTarget(frames, pos, fTgt);
        // UTAU 声库音色适配：用声库波形分析出的共振峰替换默认元音表
        if (vb != null) {
          final vf = vb.vowelFormants(_nearestSym(frames, pos));
          if (vf != null) {
            for (int i = 0; i < 4; i++) { fTgt[i] = vf[i]; }
          }
        }
        voiceAmt = 1; noiseAmt = 0; breathAmt = breath; nf = 2600; nbw = 2500;
        double a = 1.0;
        if (consTotal <= 0) a = math.min(1.0, tRel / 0.03); // 无辅音时软起音
        double rel = 1.0;
        if (tRel > dur - 0.08) {
          rel = 0.3 + 0.7 * dclamp((dur - tRel) / 0.08, 0.0, 1.0);
        }
        if (tRel > dur - 0.03) {
          rel *= dclamp((dur - tRel) / 0.03, 0.0, 1.0);
        }
        env = dclamp(a * rel, 0.0, 1.0);
      }

      // ---------- 滤波系数（块间平滑防爆音） ----------
      for (int i = 0; i < 4; i++) {
        _cur[i] += (fTgt[i] * fs - _cur[i]) * 0.5;
        bq[i].setBandpass(math.max(60.0, _cur[i]), _cur[i] / bw[i]);
      }
      nbq.setBandpass(math.max(100.0, nf), math.max(0.6, nf / math.max(200.0, nbw)));
      tiltFc += (2000 + 6000 * bright - tiltFc) * 0.5;
      tilt.setLowpass(tiltFc, 0.707);

      // ---------- 采样循环 ----------
      for (int k = 0; k < chunk; k++) {
        final t = tRel + k / _sr;
        double f0 = targetHz;
        if (t < portDur && portDur > 0.0001) {
          final su = smooth01(t / portDur);
          f0 = startHz * math.pow(targetHz / startHz, su).toDouble();
        }
        final vibE = smooth01((t - dur * 0.35) / (dur * 0.5));
        if (vibE > 0) {
          f0 *= math.pow(2.0, vibCents * math.sin(6.28318 * vibRate * t + vibPh) / 1200.0 * vibE).toDouble();
        }
        // 微音高漂移（更"人"）
        f0 *= math.pow(2.0, (5 * math.sin(1.3 * t + dph1) + 3.5 * math.sin(2.9 * t + dph2)) / 1200.0).toDouble();

        phase += f0 / _sr;
        if (phase >= 1) { phase -= 1; uPrev = 0; }
        final uu = phase * phase - phase * phase * phase; // KLGLOTT88
        final ug = (uu - uPrev) * 7.0;
        uPrev = uu;

        double s = ug * voiceAmt;
        if (breathAmt > 0) {
          s += (_rng.nextDouble() * 2 - 1) * breathAmt * 0.55; // 宽带气声
        }
        if (noiseAmt > 0) {
          s += nbq.tick(_rng.nextDouble() * 2 - 1) * noiseAmt * 1.6; // 成形辅音噪声
        }

        double o = bq[0].tick(s) + 0.6 * bq[1].tick(s) +
            0.32 * bq[2].tick(s) + 0.15 * bq[3].tick(s);
        o = tilt.tick(o);
        buf[i0 + smp + k] += o * env * gain;
      }
      tRel += chunk / _sr;
      smp += chunk;
    }
  }

  String _nearestSym(List<MapEntry<double, String>> frames, double pos) {
    var best = frames.first.value;
    double bd = 9;
    for (final e in frames) {
      final d = (e.key - pos).abs();
      if (d < bd) { bd = d; best = e.value; }
    }
    return best;
  }

  void _vowelTarget(List<MapEntry<double, String>> frames, double pos, List<double> out) {
    if (frames.length == 1 || pos <= frames.first.key) {
      for (int i = 0; i < 4; i++) { out[i] = phones[frames.first.value]!.f[i]; }
      return;
    }
    if (pos >= frames.last.key) {
      for (int i = 0; i < 4; i++) { out[i] = phones[frames.last.value]!.f[i]; }
      return;
    }
    for (int i = 0; i < frames.length - 1; i++) {
      final a = frames[i], b = frames[i + 1];
      if (pos >= a.key && pos <= b.key) {
        final u = b.key - a.key <= 0 ? 0.0 : (pos - a.key) / (b.key - a.key);
        final da = phones[a.value]!;
        final db = phones[b.value]!;
        for (int k = 0; k < 4; k++) {
          out[k] = da.f[k] + (db.f[k] - da.f[k]) * u;
        }
        return;
      }
    }
  }

  void _post(Float32List b) {
    double mx = 0;
    for (final v in b) {
      final a = v.abs();
      if (a > mx) mx = a;
    }
    if (mx < 1e-7) return;
    final g = 0.85 / mx;
    for (int i = 0; i < b.length; i++) {
      final v = b[i] * g * 1.15;
      b[i] = _tanh(v) * 0.92;
    }
  }

  double _tanh(double x) {
    if (x > 4) return 1;
    if (x < -4) return -1;
    final e = math.exp(2 * x);
    return (e - 1) / (e + 1);
  }
}

/// compute() 隔离区入口：JSON → WAV
Uint8List renderProjectIsolate(Map<String, dynamic> json) {
  final p = XNProject.fromJson(json);
  return SynthRenderer().render(p);
}