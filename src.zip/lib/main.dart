import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'home.dart';
import 'splash.dart';
import 'theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final prefs = await SharedPreferences.getInstance();
  themeNotifier.value = prefs.getInt('xn.theme') ?? 0;
  themeNotifier.addListener(() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('xn.theme', themeNotifier.value);
  });
  runApp(const XilikillApp());
}

class XilikillApp extends StatelessWidget {
  const XilikillApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: themeNotifier,
      builder: (context, _, __) {
        final th = currentTheme;
        return MaterialApp(
          title: 'Xilikill N',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            useMaterial3: true,
            brightness: th.dark ? Brightness.dark : Brightness.light,
            colorScheme: (th.dark
                    ? ColorScheme.dark(primary: th.primary, secondary: th.accent)
                    : ColorScheme.light(primary: th.primary, secondary: th.accent))
                .copyWith(surface: th.surface),
            scaffoldBackgroundColor: th.bg,
            appBarTheme: AppBarTheme(
              backgroundColor: th.surface,
              foregroundColor: th.text,
              elevation: 0,
            ),
            dialogBackgroundColor: th.surface,
          ),
          home: const SplashScreen(),
        );
      },
    );
  }
}