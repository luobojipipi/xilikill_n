/// 音素定义与歌词→音素转换
/// 共振峰值为公开语音学近似数据（女声偏高），可自行微调
class PhoneDef {
  final String type;      // v 元音 / nasal 鼻音 / liq 流音 / glide 滑音 / fri 擦音 / stop 塞音 / aff 塞擦
  final List<double> f;   // 共振峰 F1..F4（浊声部分）
  final double noise;     // 噪声强度
  final double nf;        // 噪声带通中心
  final double nbw;       // 噪声带宽
  final double voice;     // 浊声比例
  final double lenMs;     // 作辅音时的时长
  final double sil;       // 塞音静音占比
  const PhoneDef(this.type, this.f,
      {this.noise = 0, this.nf = 2000, this.nbw = 2000, this.voice = 0,
       this.lenMs = 60, this.sil = 0.5});
}

const Map<String, PhoneDef> phones = {
  // ---- 元音 ----
  'a': PhoneDef('v', [800, 1200, 2600, 3400]),
  'i': PhoneDef('v', [300, 2300, 3100, 3800]),
  'u': PhoneDef('v', [320, 850, 2400, 3400]),
  'e': PhoneDef('v', [480, 1900, 2650, 3500]),
  'o': PhoneDef('v', [460, 900, 2600, 3400]),
  'yu': PhoneDef('v', [300, 1700, 2400, 3600]),
  // ---- 鼻音 ----
  'n': PhoneDef('nasal', [250, 1400, 2700, 3400], voice: 1, noise: 0.02, lenMs: 70),
  'm': PhoneDef('nasal', [250, 1100, 2300, 3300], voice: 1, noise: 0.02, lenMs: 70),
  'ng': PhoneDef('nasal', [250, 1250, 2400, 3300], voice: 1, noise: 0.02, lenMs: 80),
  // ---- 流音 ----
  'l': PhoneDef('liq', [360, 1300, 2800, 3600], voice: 1, lenMs: 60),
  'r': PhoneDef('liq', [330, 1100, 2400, 3400], voice: 1, lenMs: 65),
  // ---- 半元音 ----
  'y': PhoneDef('glide', [280, 2200, 3000, 3800], voice: 1, lenMs: 50),
  'w': PhoneDef('glide', [300, 700, 2300, 3300], voice: 1, lenMs: 50),
  // ---- 擦音 ----
  's': PhoneDef('fri', [400, 1700, 2600, 3400], noise: 0.95, nf: 6800, nbw: 1800, lenMs: 95),
  'sh': PhoneDef('fri', [400, 1700, 2600, 3400], noise: 0.95, nf: 3300, nbw: 1600, lenMs: 100),
  'x': PhoneDef('fri', [300, 2000, 3000, 3800], noise: 0.9, nf: 4800, nbw: 2400, lenMs: 90),
  'h': PhoneDef('fri', [500, 1500, 2500, 3400], noise: 0.7, nf: 1600, nbw: 4000, lenMs: 60),
  'f': PhoneDef('fri', [400, 1200, 2400, 3400], noise: 0.9, nf: 3200, nbw: 3200, lenMs: 85),
  'v': PhoneDef('fri', [350, 1100, 2400, 3300], noise: 0.35, nf: 2400, nbw: 2500, voice: 0.6, lenMs: 70),
  'z': PhoneDef('fri', [400, 1700, 2600, 3400], noise: 0.5, nf: 6200, nbw: 1600, voice: 0.45, lenMs: 70),
  'zh': PhoneDef('fri', [400, 1600, 2600, 3400], noise: 0.55, nf: 2600, nbw: 1400, voice: 0.35, lenMs: 75),
  'j': PhoneDef('fri', [300, 2000, 3000, 3800], noise: 0.5, nf: 4000, nbw: 2200, voice: 0.4, lenMs: 70),
  // ---- 塞音 ----
  'k': PhoneDef('stop', [500, 1600, 2500, 3400], noise: 1, nf: 2400, nbw: 1800, lenMs: 55, sil: 0.5),
  't': PhoneDef('stop', [400, 1800, 2600, 3500], noise: 1, nf: 4200, nbw: 2000, lenMs: 50, sil: 0.5),
  'p': PhoneDef('stop', [400, 1100, 2300, 3300], noise: 1, nf: 1100, nbw: 1000, lenMs: 55, sil: 0.55),
  'd': PhoneDef('stop', [350, 1700, 2600, 3500], noise: 0.7, nf: 3200, nbw: 2000, voice: 0.5, lenMs: 45, sil: 0.4),
  'g': PhoneDef('stop', [350, 1400, 2400, 3300], noise: 0.7, nf: 2000, nbw: 1500, voice: 0.5, lenMs: 45, sil: 0.4),
  'b': PhoneDef('stop', [350, 1000, 2300, 3300], noise: 0.7, nf: 900, nbw: 900, voice: 0.5, lenMs: 45, sil: 0.45),
  // ---- 塞擦音 ----
  'c': PhoneDef('aff', [400, 1700, 2600, 3400], noise: 0.95, nf: 6400, nbw: 1600, lenMs: 90, sil: 0.35),
  'ch': PhoneDef('aff', [400, 1600, 2600, 3400], noise: 0.95, nf: 3000, nbw: 1500, lenMs: 100, sil: 0.35),
  'q': PhoneDef('aff', [300, 2000, 3000, 3800], noise: 0.9, nf: 4600, nbw: 2200, lenMs: 90, sil: 0.35),
  'ts': PhoneDef('aff', [400, 1700, 2600, 3400], noise: 0.95, nf: 6400, nbw: 1600, lenMs: 90, sil: 0.35),
};

/// 声母键（长键在前，贪婪匹配）
const List<String> _consKeys = [
  'ch', 'sh', 'zh', 'ts', 'ky', 'gy', 'py', 'by', 'my', 'ry', 'ny', 'hy',
  'ng', 'dz', 'b', 'p', 'm', 'f', 'v', 'd', 't', 'n', 'l', 'g', 'k', 'h',
  'j', 'q', 'x', 'z', 'c', 's', 'r', 'y', 'w',
];

/// 韵母→共振峰关键帧（pos 0..1）
const Map<String, List<MapEntry<double, String>>> _vFrames = {
  'iang': [MapEntry(0.0, 'i'), MapEntry(0.3, 'i'), MapEntry(0.7, 'a'), MapEntry(1.0, 'ng')],
  'uang': [MapEntry(0.0, 'u'), MapEntry(0.3, 'u'), MapEntry(0.7, 'a'), MapEntry(1.0, 'ng')],
  'iong': [MapEntry(0.0, 'yu'), MapEntry(0.35, 'yu'), MapEntry(0.7, 'o'), MapEntry(1.0, 'ng')],
  'ueng': [MapEntry(0.0, 'u'), MapEntry(0.3, 'u'), MapEntry(0.7, 'e'), MapEntry(1.0, 'ng')],
  'iao': [MapEntry(0.0, 'i'), MapEntry(0.3, 'i'), MapEntry(0.7, 'a'), MapEntry(1.0, 'u')],
  'uai': [MapEntry(0.0, 'u'), MapEntry(0.25, 'u'), MapEntry(0.7, 'a'), MapEntry(1.0, 'i')],
  'ian': [MapEntry(0.0, 'i'), MapEntry(0.3, 'i'), MapEntry(0.75, 'a'), MapEntry(1.0, 'n')],
  'uan': [MapEntry(0.0, 'u'), MapEntry(0.3, 'u'), MapEntry(0.75, 'a'), MapEntry(1.0, 'n')],
  'ang': [MapEntry(0.0, 'a'), MapEntry(0.7, 'a'), MapEntry(1.0, 'ng')],
  'eng': [MapEntry(0.0, 'e'), MapEntry(0.7, 'e'), MapEntry(1.0, 'ng')],
  'ong': [MapEntry(0.0, 'o'), MapEntry(0.6, 'u'), MapEntry(1.0, 'ng')],
  'ai': [MapEntry(0.0, 'a'), MapEntry(1.0, 'i')],
  'ei': [MapEntry(0.0, 'e'), MapEntry(1.0, 'i')],
  'ao': [MapEntry(0.0, 'a'), MapEntry(1.0, 'u')],
  'ou': [MapEntry(0.0, 'o'), MapEntry(1.0, 'u')],
  'an': [MapEntry(0.0, 'a'), MapEntry(0.75, 'a'), MapEntry(1.0, 'n')],
  'en': [MapEntry(0.0, 'e'), MapEntry(0.75, 'e'), MapEntry(1.0, 'n')],
  'er': [MapEntry(0.0, 'e'), MapEntry(1.0, 'r')],
  'ia': [MapEntry(0.0, 'i'), MapEntry(0.35, 'i'), MapEntry(1.0, 'a')],
  'ie': [MapEntry(0.0, 'i'), MapEntry(0.35, 'i'), MapEntry(1.0, 'e')],
  'iu': [MapEntry(0.0, 'i'), MapEntry(0.3, 'i'), MapEntry(0.7, 'o'), MapEntry(1.0, 'u')],
  'in': [MapEntry(0.0, 'i'), MapEntry(0.7, 'i'), MapEntry(1.0, 'n')],
  'ing': [MapEntry(0.0, 'i'), MapEntry(0.7, 'i'), MapEntry(1.0, 'ng')],
  'ua': [MapEntry(0.0, 'u'), MapEntry(0.35, 'u'), MapEntry(1.0, 'a')],
  'uo': [MapEntry(0.0, 'u'), MapEntry(0.35, 'u'), MapEntry(1.0, 'o')],
  'ui': [MapEntry(0.0, 'u'), MapEntry(0.3, 'u'), MapEntry(0.7, 'e'), MapEntry(1.0, 'i')],
  'un': [MapEntry(0.0, 'u'), MapEntry(0.6, 'u'), MapEntry(1.0, 'n')],
  'ue': [MapEntry(0.0, 'yu'), MapEntry(0.35, 'yu'), MapEntry(1.0, 'e')],
  've': [MapEntry(0.0, 'yu'), MapEntry(0.35, 'yu'), MapEntry(1.0, 'e')],
  'vn': [MapEntry(0.0, 'yu'), MapEntry(0.7, 'yu'), MapEntry(1.0, 'n')],
  'ee': [MapEntry(0.0, 'i')],
  'oo': [MapEntry(0.0, 'u')],
  'ea': [MapEntry(0.0, 'i'), MapEntry(1.0, 'a')],
  'oi': [MapEntry(0.0, 'o'), MapEntry(0.5, 'o'), MapEntry(1.0, 'i')],
  'oy': [MapEntry(0.0, 'o'), MapEntry(1.0, 'i')],
  'ay': [MapEntry(0.0, 'e'), MapEntry(1.0, 'i')],
  'ey': [MapEntry(0.0, 'e'), MapEntry(1.0, 'i')],
  'aw': [MapEntry(0.0, 'a'), MapEntry(1.0, 'u')],
  'ow': [MapEntry(0.0, 'a'), MapEntry(1.0, 'u')],
  'a': [MapEntry(0.0, 'a')],
  'i': [MapEntry(0.0, 'i')],
  'u': [MapEntry(0.0, 'u')],
  'e': [MapEntry(0.0, 'e')],
  'o': [MapEntry(0.0, 'o')],
  'n': [MapEntry(0.0, 'n')],
};

final List<String> _vKeys =
    _vFrames.keys.toList()..sort((a, b) => b.length.compareTo(a.length));

/// 日文假名（平/片）→ 罗马字
const Map<String, String> _kana = {
  'あ': 'a', 'い': 'i', 'う': 'u', 'え': 'e', 'お': 'o',
  'か': 'ka', 'き': 'ki', 'く': 'ku', 'け': 'ke', 'こ': 'ko',
  'が': 'ga', 'ぎ': 'gi', 'ぐ': 'gu', 'げ': 'ge', 'ご': 'go',
  'さ': 'sa', 'し': 'shi', 'す': 'su', 'せ': 'se', 'そ': 'so',
  'ざ': 'za', 'じ': 'ji', 'ず': 'zu', 'ぜ': 'ze', 'ぞ': 'zo',
  'た': 'ta', 'ち': 'chi', 'つ': 'tsu', 'て': 'te', 'と': 'to',
  'だ': 'da', 'ぢ': 'ji', 'づ': 'zu', 'で': 'de', 'ど': 'do',
  'な': 'na', 'に': 'ni', 'ぬ': 'nu', 'ね': 'ne', 'の': 'no',
  'は': 'ha', 'ひ': 'hi', 'ふ': 'fu', 'へ': 'he', 'ほ': 'ho',
  'ば': 'ba', 'び': 'bi', 'ぶ': 'bu', 'べ': 'be', 'ぼ': 'bo',
  'ぱ': 'pa', 'ぴ': 'pi', 'ぷ': 'pu', 'ぺ': 'pe', 'ぽ': 'po',
  'ま': 'ma', 'み': 'mi', 'む': 'mu', 'め': 'me', 'も': 'mo',
  'や': 'ya', 'ゆ': 'yu', 'よ': 'yo',
  'ら': 'ra', 'り': 'ri', 'る': 'ru', 'れ': 're', 'ろ': 'ro',
  'わ': 'wa', 'ゐ': 'i', 'ゑ': 'e', 'を': 'o', 'ん': 'n',
  'ゔ': 'vu', 'ぁ': 'a', 'ぃ': 'i', 'ぅ': 'u', 'ぇ': 'e', 'ぉ': 'o',
  'ゃ': 'ya', 'ゅ': 'yu', 'ょ': 'yo',
};

const _smallYouon = ['ゃ', 'ゅ', 'ょ', 'ャ', 'ュ', 'ョ'];

bool _hasKana(String s) {
  for (final r in s.runes) {
    if (r >= 0x3040 && r <= 0x30FF) return true;
  }
  return false;
}

String _kanaToRomaji(String s) {
  final sb = StringBuffer();
  String last = '';
  for (final raw in s.runes) {
    var cd = raw;
    if (cd >= 0x30A1 && cd <= 0x30F6) cd -= 0x60; // 片假名→平假名
    final c = String.fromCharCode(cd);
    if (c == 'っ') continue;
    if (c == 'ー') {
      if (last.isNotEmpty && 'aiueo'.contains(last[last.length - 1])) {
        sb.write(last[last.length - 1]);
      } else {
        sb.write('a');
      }
      continue;
    }
    final rom = _kana[c];
    if (rom == null) continue;
    if (_smallYouon.contains(c) &&
        last.length >= 2 &&
        !'aiueo'.contains(last[last.length - 1])) {
      // 拗音：き + ゃ → kya
      final merged = last.substring(0, last.length - 1) + rom;
      sb.write(merged);
      last = merged;
    } else {
      sb.write(rom);
      last = rom;
    }
  }
  return sb.toString();
}

class Phones {
  final List<String> cons;                          // 辅音序列
  final List<MapEntry<double, String>> frames;      // 元音关键帧 pos∈[0,1]
  const Phones(this.cons, this.frames);
}

/// 歌词 → 音素（支持：拼音 / 日文罗马字 / 假名 / 简单英文近似）
Phones lyricToPhones(String lyric) {
  var s = lyric.trim().toLowerCase();
  if (s.isEmpty) return const Phones([], [MapEntry(0.0, 'a')]);
  if (_hasKana(s)) s = _kanaToRomaji(s);

  final cons = <String>[];
  final frames = <MapEntry<double, String>>[];
  int nSyl = 0;
  int i = 0;

  while (i < s.length && nSyl < 12) {
    // 1) 贪婪匹配声母
    String? c;
    for (final k in _consKeys) {
      if (s.startsWith(k, i)) { c = k; break; }
    }
    if (c != null) i += c.length;
    // 2) 贪婪匹配韵母
    String? v;
    for (final k in _vKeys) {
      if (s.startsWith(k, i)) { v = k; break; }
    }
    // 3) 拨音 n/ng 单独成拍
    if (v == null && c != null && (c == 'n' || c == 'ng')) {
      frames.add(MapEntry(nSyl.toDouble(), 'n'));
      nSyl++;
      continue;
    }
    // 4) 未知字母兜底
    if (v == null) {
      if (i >= s.length) break;
      final ch = s[i];
      if (_vFrames.containsKey(ch)) {
        v = ch;
      } else if (ch.contains(RegExp(r'[a-z]'))) {
        c = ch; i++; v = 'a';
      } else {
        i++; continue;
      }
    }
    i += v.length;
    if (c != null) cons.add(c);
    final fr = _vFrames[v]!;
    for (final e in fr) {
      frames.add(MapEntry(nSyl.toDouble() + e.key, e.value));
    }
    nSyl++;
  }

  if (frames.isEmpty) {
    return const Phones([], [MapEntry(0.0, 'a')]);
  }
  final norm = [
    for (final e in frames) MapEntry(e.key / nSyl, e.value)
  ];
  return Phones(cons, norm);
}