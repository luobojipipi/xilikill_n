import 'package:yaml/yaml.dart';
import 'models.dart';

/// OpenUtau .ustx 导入（宽容解析，参考其公开 YAML 结构）
class UstxImport {
  static double _n(dynamic v, double def) => v is num ? v.toDouble() : def;
  static int _i(dynamic v, int def) => v is num ? v.toInt() : def;

  static XNProject? parse(String text, String name) {
    dynamic doc;
    try {
      doc = loadYaml(text);
    } catch (_) {
      return null;
    }
    if (doc is! YamlMap) return null;

    final tempo = TempoMap();
    final bpm = _n(doc['bpm'], 120);
    tempo.segs[0].bpm = bpm;

    final res = _i(doc['resolution'], 480);
    final scale = TempoMap.tpq / (res <= 0 ? 480 : res);

    // tempo_map: [{position, bpm}, ...]
    final tm = doc['tempo_map'];
    if (tm is YamlList) {
      for (final e in tm) {
        if (e is YamlMap) {
          final t = (_i(e['position'], 0) * scale).round();
          final b = _n(e['bpm'], bpm);
          if (t > 0) {
            tempo.segs.add(TempoSeg(tick: t, bpm: b));
          } else {
            tempo.segs[0].bpm = b;
          }
        }
      }
    }

    // time_sig（可能是单个 map 或列表）
    final ts = doc['time_sig'];
    if (ts is YamlMap) {
      tempo.segs[0].beatsPerBar = _i(ts['numerator'], 4);
      final den = _i(ts['denominator'], 4);
      if (den > 0) tempo.segs[0].beatTicks = (TempoMap.tpq * 4.0 / den).round();
    } else if (ts is YamlList && ts.isNotEmpty && ts.first is YamlMap) {
      final m = ts.first as YamlMap;
      tempo.segs[0].beatsPerBar = _i(m['numerator'], 4);
      final den = _i(m['denominator'], 4);
      if (den > 0) tempo.segs[0].beatTicks = (TempoMap.tpq * 4.0 / den).round();
    }

    // 音符：优先顶层 notes，否则找第一条含 notes 的轨道
    YamlList? notes = doc['notes'] is YamlList ? doc['notes'] as YamlList : null;
    if (notes == null && doc['tracks'] is YamlList) {
      for (final e in doc['tracks']) {
        if (e is YamlMap && e['notes'] is YamlList) {
          notes = e['notes'] as YamlList;
          break;
        }
      }
    }

    final track = XNTrack(name: 'Voice', colorValue: 0xFF4FC3F7);
    if (notes != null) {
      for (final e in notes) {
        if (e is! YamlMap) continue;
        final pos = (_i(e['position'], 0) * scale).round();
        final len = (_i(e['length'], TempoMap.tpq) * scale).round();
        final key = _i(e['key_number'], 60).clamp(21, 108);
        final ly = e['lyric']?.toString() ?? 'a';
        track.notes.add(XNNote(pitch: key, start: pos, length: len.clamp(30, 200000), lyric: ly));
      }
    }
    tempo.normalize();
    return XNProject(name: name, tempo: tempo, tracks: [track]);
  }
}