import 'dart:convert';
import 'dart:io';
import 'dsp.dart';

class OtoEntry {
  final String file;
  final double offset; // 波形起始偏移 ms（oto.ini 第 1 参数）
  OtoEntry(this.file, this.offset);
}

/// UTAU 声库：
///  - 解析 oto.ini（别名 → 源 wav + 偏移，参考 UTAU 公开格式规范）
///  - 解析 character.txt 中的 name
///  - 分析元音波形，提取共振峰特征，供合成引擎做音色适配
class UtauVoicebank {
  final String dir;
  String name = '';
  final Map<String, OtoEntry> oto = {};
  final Map<String, List<double>> formants = {};

  UtauVoicebank(this.dir);

  List<double>? vowelFormants(String v) => formants[v];

  static bool looksLikeVoicebank(String dirPath) {
    try {
      final dir = Directory(dirPath);
      if (!dir.existsSync()) return false;
      if (File('$dirPath/oto.ini').existsSync()) return true;
      for (final e in dir.listSync()) {
        if (e is Directory && File('${e.path}/oto.ini').existsSync()) return true;
        if (e is Directory) {
          for (final s in e.listSync()) {
            if (s is Directory && File('${s.path}/oto.ini').existsSync()) return true;
          }
        }
      }
    } catch (_) {}
    return false;
  }

  static List<String> _readLines(File f) {
    final bytes = f.readAsBytesSync();
    String text;
    try {
      text = utf8.decode(bytes, allowMalformed: true);
      if (text.contains('\uFFFD')) text = latin1.decode(bytes, allowInvalid: true);
    } catch (_) {
      text = latin1.decode(bytes, allowInvalid: true);
    }
    return text.split(RegExp(r'\r?\n'));
  }

  static UtauVoicebank? loadSync(String dirPath) {
    try {
      final dir = Directory(dirPath);
      if (!dir.existsSync()) return null;
      final vb = UtauVoicebank(dirPath);

      // ---- 找 oto.ini / character.txt ----
      File? otoF, charF;
      final otoCandidates = <File>[File('$dirPath/oto.ini')];
      final charCandidates = <File>[File('$dirPath/character.txt')];
      try {
        for (final e in dir.listSync()) {
          if (e is Directory) {
            otoCandidates.add(File('${e.path}/oto.ini'));
            charCandidates.add(File('${e.path}/character.txt'));
            for (final s in e.listSync()) {
              if (s is Directory) {
                otoCandidates.add(File('${s.path}/oto.ini'));
                charCandidates.add(File('${s.path}/character.txt'));
              }
            }
          }
        }
      } catch (_) {}
      for (final f in otoCandidates) { if (f.existsSync()) { otoF = f; break; } }
      for (final f in charCandidates) { if (f.existsSync()) { charF = f; break; } }

      // ---- character.txt → name ----
      if (charF != null) {
        for (final line in _readLines(charF)) {
          if (line.startsWith('name=')) {
            name = line.substring(5).trim();
            break;
          }
        }
      }

      if (otoF == null) return vb;

      // ---- oto.ini ----
      for (final line in _readLines(otoF)) {
        final eq = line.indexOf('=');
        if (eq < 0) continue;
        final alias = line.substring(0, eq).trim();
        final parts = line.substring(eq + 1).split(',');
        if (parts.length < 6) continue;
        final file = parts[0].trim();
        final offset = double.tryParse(parts[1].trim()) ?? 0;
        if (alias.isNotEmpty && file.isNotEmpty) {
          oto[alias] = OtoEntry(file, offset);
        }
      }

      // ---- 分析元音共振峰 ----
      const kanaV = {'a': 'あ', 'i': 'い', 'u': 'う', 'e': 'え', 'o': 'お'};
      final base = otoF.parent.path;
      for (final v in ['a', 'i', 'u', 'e', 'o']) {
        String? alias;
        if (oto.containsKey(v)) alias = v;
        final kv = kanaV[v];
        if (alias == null && kv != null && oto.containsKey(kv)) alias = kv;
        if (alias == null && v == 'a' && oto.isNotEmpty) alias = oto.keys.first;
        if (alias == null) continue;
        final f = _analyze(vb, base, alias);
        if (f != null) vb.formants[v] = f;
      }
      return vb;
    } catch (_) {
      return null;
    }
  }

  static List<double>? _analyze(UtauVoicebank vb, String base, String alias) {
    final e = vb.oto[alias];
    if (e == null) return null;
    var wav = File('$base/${e.file}');
    if (!wav.existsSync()) {
      try {
        for (final d in Directory(base).listSync()) {
          if (d is Directory) {
            final f2 = File('${d.path}/${e.file}');
            if (f2.existsSync()) { wav = f2; break; }
          }
        }
      } catch (_) {}
    }
    if (!wav.existsSync()) return null;
    final pcm = readWavMonoSync(wav.path);
    if (pcm == null) return null;
    return extractFormants(pcm.$1, pcm.$2);
  }
}