import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'editor.dart';
import 'io.dart';
import 'models.dart';
import 'splash.dart';
import 'theme.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<Map<String, dynamic>> _files = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() => _loading = true);
    _files = await listProjects();
    if (mounted) setState(() => _loading = false);
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating));
  }

  Future<String?> _askName(String title, String hint) async {
    final ctl = TextEditingController(text: hint);
    final th = currentTheme;
    return showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: th.surface,
        title: Text(title, style: TextStyle(color: th.text)),
        content: TextField(
          controller: ctl,
          autofocus: true,
          style: TextStyle(color: th.text),
          decoration: InputDecoration(hintText: hint, labelText: '工程名称'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctl.text), child: const Text('确定')),
        ],
      ),
    );
  }

  Future<void> _newProject() async {
    final name = await _askName('新建工程', '我的歌声工程');
    if (name == null || name.trim().isEmpty) return;
    final p = XNProject(name: name.trim());
    // 附带示例乐句，可直接试听
    p.tracks.first.notes.add(XNNote(pitch: 60, start: 0, length: 480, lyric: 'do'));
    p.tracks.first.notes.add(XNNote(pitch: 62, start: 480, length: 480, lyric: 're'));
    p.tracks.first.notes.add(XNNote(pitch: 64, start: 960, length: 480, lyric: 'mi'));
    p.tracks.first.notes.add(XNNote(pitch: 67, start: 1440, length: 960, lyric: 'so'));
    await saveProject(p);
    await _open(p);
  }

  Future<void> _import() async {
    final res = await FilePicker.platform.pickFiles(type: FileType.any);
    final path = res?.files.single.path;
    if (path == null) return;
    final p = await loadAny(path);
    if (p == null) {
      _toast('导入失败：不支持的文件格式');
      return;
    }
    _toast('导入成功：${p.name}（${p.tracks.fold<int>(0, (a, t) => a + t.notes.length)} 音符）');
    await _open(p);
  }

  Future<void> _open(XNProject p) async {
    await Navigator.of(context)
        .push(MaterialPageRoute(builder: (_) => EditorPage(project: p)));
    _refresh();
  }

  @override
  Widget build(BuildContext context) {
    final th = currentTheme;
    return Scaffold(
      backgroundColor: th.bg,
      appBar: AppBar(
        backgroundColor: th.bg,
        foregroundColor: th.text,
        title: Row(children: [
          SizedBox(width: 34, height: 34, child: CustomPaint(painter: LogoPainter(th.primary, th.accent))),
          const SizedBox(width: 10),
          Text('Xilikill N', style: TextStyle(color: th.text, fontWeight: FontWeight.w900, letterSpacing: 2)),
        ]),
        actions: [
          IconButton(onPressed: _import, icon: const Icon(Icons.file_open_outlined), tooltip: '导入工程'),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _newProject,
        backgroundColor: th.primary,
        foregroundColor: th.dark ? th.bg : Colors.white,
        icon: const Icon(Icons.add),
        label: const Text('新建工程'),
      ),
      body: _loading
          ? Center(child: CircularProgressIndicator(color: th.primary))
          : _files.isEmpty
              ? Center(child: Text('还没有工程，点击右下角新建吧', style: TextStyle(color: th.dim)))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(12, 8, 12, 90),
                  itemCount: _files.length,
                  itemBuilder: (context, i) {
                    final f = _files[i];
                    final mt = f['mtime'] as DateTime;
                    return Card(
                      color: th.surface,
                      margin: const EdgeInsets.symmetric(vertical: 5),
                      child: ListTile(
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        leading: Icon(Icons.music_note_rounded, color: th.primary),
                        title: Text('${f['name']}', style: TextStyle(color: th.text, fontWeight: FontWeight.w700)),
                        subtitle: Text(
                            '${mt.year}-${mt.month.toString().padLeft(2, '0')}-${mt.day.toString().padLeft(2, '0')} ${mt.hour.toString().padLeft(2, '0')}:${mt.minute.toString().padLeft(2, '0')}',
                            style: TextStyle(color: th.dim, fontSize: 12)),
                        onTap: () async {
                          final p = await loadAny(f['path'] as String);
                          if (p == null) { _toast('文件损坏或格式不支持'); return; }
                          await _open(p);
                        },
                        onLongPress: () async {
                          final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
                            backgroundColor: th.surface,
                            title: Text('删除工程？', style: TextStyle(color: th.text)),
                            content: Text('${f['name']}', style: TextStyle(color: th.dim)),
                            actions: [
                              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
                              FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('删除')),
                            ],
                          ));
                          if (ok == true) {
                            await deleteProject(f['path'] as String);
                            _refresh();
                          }
                        },
                      ),
                    );
                  },
                ),
    );
  }
}