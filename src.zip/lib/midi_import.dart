import 'models.dart';

/// 标准 MIDI File 解析（含 tempo / time signature 元事件）
class MidiImport {
  static int _u32(List<int> d, int p) =>
      (d[p] << 24) | (d[p + 1] << 16) | (d[p + 2] << 8) | d[p + 3];
  static int _u16(List<int> d, int p) => (d[p] << 8) | d[p + 1];

  static int _vlq(List<int> d, List<int> pos, int end) {
    int v = 0;
    while (pos[0] < end) {
      final b = d[pos[0]++];
      v = (v << 7) | (b & 0x7F);
      if (b & 0x80 == 0) break;
    }
    return v;
  }

  static XNProject? parse(List<int> d, String name) {
    if (d.length < 14) return null;
    if (d[0] != 0x4D || d[1] != 0x54 || d[2] != 0x68 || d[3] != 0x64) return null; // MThd
    final hlen = _u32(d, 4);
    final ntrk = _u16(d, 10);
    final div = _u16(d, 12);
    if (div & 0x8000 != 0) return null; // 不支持 SMPTE
    final srcTpq = div == 0 ? 480 : div;

    final tempoTicks = <int>[], tempoVals = <double>[];
    final tsTicks = <int>[], tsBeats = <int>[], tsBeatTicks = <int>[];
    final starts = <int>[], ends = <int>[], midis = <int>[];
    final open = <int, List<int>>{};

    void noteOff(int key, int tick) {
      final lst = open[key];
      if (lst != null && lst.isNotEmpty) {
        final s = lst.removeLast();
        if (tick > s + 10) {
          starts.add(s); ends.add(tick); midis.add(key & 0xFF);
        }
      }
    }

    int p = 8 + hlen;
    for (int t = 0; t < ntrk && p + 8 <= d.length; t++) {
      final len = _u32(d, p + 4);
      if (d[p] != 0x4D || d[p + 1] != 0x54 || d[p + 2] != 0x72 || d[p + 3] != 0x6B) {
        p += 8 + len;
        continue;
      }
      final end = p + 8 + len;
      final pos = [p + 8];
      int tick = 0, run = 0;
      while (pos[0] < end) {
        tick += _vlq(d, pos, end);
        if (pos[0] >= end) break;
        int st = d[pos[0]++];
        if (st < 0x80) {
          pos[0]--; st = run;
        } else if (st < 0xF0) {
          run = st;
        }
        final hi = st & 0xF0;
        if (st == 0xFF) {
          if (pos[0] >= end) break;
          final type = d[pos[0]++];
          final mlen = _vlq(d, pos, end);
          if (type == 0x51 && mlen >= 3 && pos[0] + 3 <= end) {
            final us = (d[pos[0]] << 16) | (d[pos[0] + 1] << 8) | d[pos[0] + 2];
            tempoTicks.add(tick);
            tempoVals.add(us <= 0 ? 120.0 : 60000000.0 / us);
          } else if (type == 0x58 && mlen >= 2 && pos[0] + 2 <= end) {
            final nn = d[pos[0]], dd = d[pos[0] + 1];
            tsTicks.add(tick);
            tsBeats.add(nn == 0 ? 4 : nn);
            tsBeatTicks.add((srcTpq * 4.0 / (1 << dd)).round());
          }
          pos[0] += mlen;
        } else if (st == 0xF0 || st == 0xF7) {
          pos[0] += _vlq(d, pos, end);
        } else if (hi == 0x90) {
          final note = d[pos[0]++]; final vel = d[pos[0]++];
          final ch = st & 0x0F;
          if (vel > 0 && ch != 9) {
            open.putIfAbsent((ch << 8) | note, () => []).add(tick);
          } else {
            noteOff((ch << 8) | note, tick);
          }
        } else if (hi == 0x80) {
          final note = d[pos[0]++];
          pos[0]++;
          noteOff(((st & 0x0F) << 8) | note, tick);
        } else if (hi == 0xA0 || hi == 0xB0 || hi == 0xE0) {
          pos[0] += 2;
        } else if (hi == 0xC0 || hi == 0xD0) {
          pos[0] += 1;
        }
      }
      p = end;
    }

    // ---- 速度/拍号表 ----
    final tempo = TempoMap();
    final m = <int, double>{};
    for (int i = 0; i < tempoTicks.length; i++) { m[tempoTicks[i]] = tempoVals[i]; }
    final keys = m.keys.toList()..sort();
    tempo.segs.clear();
    for (final k in keys) {
      int beats = 4, bt = srcTpq;
      for (int i = 0; i < tsTicks.length; i++) {
        if (tsTicks[i] <= k) { beats = tsBeats[i]; bt = tsBeatTicks[i]; }
      }
      tempo.segs.add(TempoSeg(tick: k, bpm: m[k]!, beatsPerBar: beats, beatTicks: bt));
    }
    if (tempo.segs.isEmpty) {
      tempo.segs.add(TempoSeg(tick: 0, bpm: 120, beatsPerBar: 4, beatTicks: srcTpq));
    }
    if (tempo.segs.first.tick > 0) {
      tempo.segs.insert(0, TempoSeg(tick: 0, bpm: tempo.segs.first.bpm,
          beatsPerBar: tempo.segs.first.beatsPerBar, beatTicks: tempo.segs.first.beatTicks));
    }
    // 缩放到内部 tpq=480
    final sc = TempoMap.tpq / srcTpq;
    for (final s in tempo.segs) {
      s.tick = (s.tick * sc).round();
      s.beatTicks = (s.beatTicks * sc).round();
    }
    tempo.normalize();

    final track = XNTrack(name: 'MIDI 导入', colorValue: 0xFFFFB74D);
    for (int i = 0; i < starts.length; i++) {
      final st = (starts[i] * sc).round();
      final ln = math2max(30, ((ends[i] - starts[i]) * sc).round());
      track.notes.add(XNNote(pitch: midis[i].clamp(21, 108), start: st, length: ln, lyric: 'a'));
    }
    return XNProject(name: name, tempo: tempo, tracks: [track]);
  }

  static int math2max(int a, int b) => a > b ? a : b;
}