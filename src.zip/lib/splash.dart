import 'package:flutter/material.dart';
import 'home.dart';
import 'theme.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override State<SplashScreen> createState() => _SplashState();
}

class _SplashState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
      vsync: this, duration: const Duration(milliseconds: 2800));

  @override
  void initState() {
    super.initState();
    _c.forward();
    _c.addStatusListener((s) {
      if (s == AnimationStatus.completed && mounted) {
        Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (_) => const HomePage()));
      }
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  String _stage(double t) {
    if (t < 0.35) return '正在初始化合成引擎…';
    if (t < 0.7) return '正在装载音素库…';
    if (t < 0.95) return '正在准备工程…';
    return '就绪';
  }

  @override
  Widget build(BuildContext context) {
    final th = currentTheme;
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft, end: Alignment.bottomRight,
            colors: [th.bg, th.bg2, Color.lerp(th.bg, th.primary, 0.15)!],
          ),
        ),
        child: SafeArea(
          child: Center(
            child: AnimatedBuilder(
              animation: _c,
              builder: (context, _) {
                final t = _c.value;
                final appear = _sm((t / 0.35).clamp(0.0, 1.0));
                return Opacity(
                  opacity: appear,
                  child: Transform.scale(
                    scale: 0.7 + 0.3 * appear,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        SizedBox(
                            width: 150, height: 150,
                            child: CustomPaint(painter: LogoPainter(th.primary, th.accent))),
                        const SizedBox(height: 28),
                        Text('XILIKILL N',
                            style: TextStyle(fontSize: 34, fontWeight: FontWeight.w900,
                                color: th.text, letterSpacing: 10)),
                        const SizedBox(height: 8),
                        Text('MOBILE SINGING VOICE STUDIO',
                            style: TextStyle(fontSize: 11, color: th.dim, letterSpacing: 4)),
                        const SizedBox(height: 48),
                        SizedBox(
                          width: 190,
                          child: LinearProgressIndicator(
                              value: t, minHeight: 3,
                              backgroundColor: th.dim.withAlpha(60), color: th.primary),
                        ),
                        const SizedBox(height: 14),
                        Text(_stage(t), style: TextStyle(fontSize: 11, color: th.dim)),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  double _sm(double x) { final v = x.clamp(0.0, 1.0); return v * v * (3 - 2 * v); }
}

/// Logo：圆环 + 声波弧 + N
class LogoPainter extends CustomPainter {
  final Color primary, accent;
  LogoPainter(this.primary, this.accent);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.shortestSide * 0.5;
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = r * 0.07
      ..color = primary;
    canvas.drawCircle(c, r * 0.92, ring);
    canvas.drawCircle(c, r * 0.74, ring..color = primary.withAlpha(90));
    for (int i = 0; i < 3; i++) {
      canvas.drawArc(
        Rect.fromCircle(center: c, radius: r * (0.28 + i * 0.13)),
        -2.2, 1.2, false,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = r * 0.055
          ..color = accent
          ..strokeCap = StrokeCap.round,
      );
    }
    final tp = TextPainter(
      text: TextSpan(text: 'N', style: TextStyle(
          fontSize: r * 0.9, fontWeight: FontWeight.w900, color: primary)),
      textDirection: TextDirection.ltr,
    )..layout();
    tp.paint(canvas, c - Offset(tp.width / 2, tp.height / 2));
  }

  @override
  bool shouldRepaint(covariant LogoPainter oldDelegate) =>
      oldDelegate.primary != primary || oldDelegate.accent != accent;
}