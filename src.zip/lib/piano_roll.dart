import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'models.dart';
import 'theme.dart';

int _iclamp(int v, int a, int b) => v < a ? a : (v > b ? b : v);
double _dclamp(double v, double a, double b) => v < a ? a : (v > b ? b : v);

/// 钢琴窗：绘制/选择/分片/删除，双指缩放平移，变拍变 BPM 网格
class PianoRoll extends StatefulWidget {
  final XNProject project;
  final String tool; // select / draw / split / delete
  final int? selectedId;
  final int playTick;
  final int snapDiv;
  final VoidCallback onChanged;
  final ValueChanged<XNNote?> onNoteSelected;

  const PianoRoll({
    super.key,
    required this.project,
    required this.tool,
    required this.selectedId,
    required this.playTick,
    required this.snapDiv,
    required this.onChanged,
    required this.onNoteSelected,
  });

  @override State<PianoRoll> createState() => _PianoRollState();
}

class _PianoRollState extends State<PianoRoll> {
  static const double _rowH = 15.0;
  static const double _keyW = 44.0;
  double _pxPerBeat = 110;
  double _xOffset = 0;
  double _topMidi = 97;

  Offset? _focalStart;
  double _zoomStart = 110, _xStart = 0, _topStart = 97;
  XNNote? _dragNote;
  int _grabTick = 0;
  bool _gestureEdited = false;

  XNProject get p => widget.project;

  int get _snapTick => math.max(1, TempoMap.tpq ~/ widget.snapDiv);

  int _tickAt(double x) =>
      ((x - _keyW + _xOffset) / _pxPerBeat * TempoMap.tpq).round();
  double _xOf(int tick) => tick / TempoMap.tpq * _pxPerBeat - _xOffset + _keyW;
  int _midiAt(double y) => (_topMidi - y / _rowH).round();
  double _yOf(int midi) => (_topMidi - midi) * _rowH;

  (XNTrack, XNNote)? _hitNote(Offset local) {
    final tick = _tickAt(local.dx);
    final midi = _midiAt(local.dy);
    for (final tr in p.tracks) {
      for (final n in tr.notes) {
        if (n.pitch == midi && tick >= n.start && tick < n.end) return (tr, n);
      }
    }
    return null;
  }

  void _addNote(Offset local) {
    final tick = (_tickAt(local.dx) ~/ _snapTick) * _snapTick;
    final midi = _midiAt(local.dy);
    final note = XNNote(
      pitch: _iclamp(midi, 21, 108),
      start: math.max(0, tick),
      length: TempoMap.tpq,
      lyric: 'a',
      brightness: p.defBrightness,
      breathiness: p.defBreathiness,
      vibratoDepth: p.defVibratoDepth,
      vibratoRate: p.defVibratoRate,
    );
    p.tracks.first.notes.add(note);
    widget.onChanged();
    widget.onNoteSelected(note);
  }

  void _splitAt(Offset local) {
    final hit = _hitNote(local);
    if (hit == null) return;
    final tick = (_tickAt(local.dx) ~/ _snapTick) * _snapTick;
    final n = hit.$2;
    if (tick > n.start + 30 && tick < n.end - 30) {
      hit.$1.notes.add(n.split(tick));
      widget.onChanged();
      setState(() {});
    }
  }

  void _deleteAt(Offset local) {
    final hit = _hitNote(local);
    if (hit != null) {
      hit.$1.notes.remove(hit.$2);
      _gestureEdited = true;
      setState(() {});
    }
  }

  @override
  Widget build(BuildContext context) {
    final th = currentTheme;
    return Column(children: [
      // ---- 标尺 ----
      GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapUp: (_) => _editTempoDialog(),
        child: CustomPaint(
          size: const Size(double.infinity, 26),
          painter: _RulerPainter(project: p, th: th, pxPerBeat: _pxPerBeat, xOffset: _xOffset, keyW: _keyW),
        ),
      ),
      // ---- 琴格 ----
      Expanded(
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onScaleStart: (d) {
            _zoomStart = _pxPerBeat;
            _xStart = _xOffset;
            _topStart = _topMidi;
            _focalStart = d.localFocalPoint;
            _gestureEdited = false;
          },
          onScaleUpdate: (d) {
            if (d.pointerCount >= 2) {
              final f = _focalStart!;
              final newPpb = _dclamp(_zoomStart * d.scale, 18.0, 1200.0);
              _xOffset = (f.dx - _keyW + _xStart) * newPpb / _zoomStart - (f.dx - _keyW);
              _pxPerBeat = newPpb;
              _topMidi = _dclamp(
                  _topStart + (f.dy - d.localFocalPoint.dy) / _rowH, 20.0, 110.0);
              setState(() {});
            } else if (_dragNote != null) {
              final n = _dragNote!;
              final snap = _snapTick;
              n.start = math.max(0,
                  ((_tickAt(d.localFocalPoint.dx) - _grabTick) ~/ snap) * snap);
              n.pitch = _iclamp(_midiAt(d.localFocalPoint.dy), 21, 108);
              _gestureEdited = true;
              setState(() {});
            } else {
              _xOffset = _dclamp(_xStart - (d.localFocalPoint.dx - _focalStart!.dx), -200.0, 100000.0);
              _topMidi = _dclamp(_topStart + (_focalStart!.dy - d.localFocalPoint.dy) / _rowH, 20.0, 110.0);
              setState(() {});
            }
          },
          onScaleEnd: (_) {
            if (_dragNote != null) {
              _dragNote = null;
              widget.onChanged();
            } else if (_gestureEdited && widget.tool == 'delete') {
              widget.onChanged();
            }
            _gestureEdited = false;
          },
          onTapUp: (d) {
            final hit = _hitNote(d.localPosition);
            switch (widget.tool) {
              case 'draw':
                if (hit != null) {
                  widget.onNoteSelected(hit.$2);
                } else {
                  _addNote(d.localPosition);
                }
                break;
              case 'select':
                widget.onNoteSelected(hit?.$2);
                break;
              case 'split':
                _splitAt(d.localPosition);
                break;
              case 'delete':
                _deleteAt(d.localPosition);
                widget.onChanged();
                break;
            }
          },
          onLongPressStart: (d) {
            final hit = _hitNote(d.localPosition);
            if (widget.tool == 'delete') {
              _deleteAt(d.localPosition);
            } else if (hit != null && widget.tool != 'draw') {
              _dragNote = hit.$2;
              _grabTick = _tickAt(d.localPosition.dx) - hit.$2.start;
              setState(() {});
            }
          },
          onLongPressMoveUpdate: (d) {
            if (widget.tool == 'delete') {
              _deleteAt(d.localPosition);
              return;
            }
            final n = _dragNote;
            if (n == null) return;
            final snap = _snapTick;
            n.start = math.max(0, ((_tickAt(d.localFocalPoint.dx) - _grabTick) ~/ snap) * snap);
            n.pitch = _iclamp(_midiAt(d.localFocalPoint.dy), 21, 108);
            setState(() {});
          },
          onLongPressEnd: (_) {
            if (_dragNote != null) {
              _dragNote = null;
              widget.onChanged();
            } else if (_gestureEdited) {
              widget.onChanged();
            }
          },
          child: CustomPaint(
            size: Size.infinite,
            painter: _RollPainter(
              project: p, th: th,
              pxPerBeat: _pxPerBeat, xOffset: _xOffset,
              topMidi: _topMidi, rowH: _rowH, keyW: _keyW,
              selectedId: widget.selectedId, playTick: widget.playTick,
              snapDiv: widget.snapDiv,
            ),
          ),
        ),
      ),
    ]);
  }

  void _editTempoDialog() {}
}

class _RulerPainter extends CustomPainter {
  final XNProject project;
  final XNTheme th;
  final double pxPerBeat, xOffset, keyW;

  _RulerPainter({required this.project, required this.th,
      required this.pxPerBeat, required this.xOffset, required this.keyW});

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = th.surface);
    final tp = TextPainter(textDirection: TextDirection.ltr);
    final maxTick = ((size.width - keyW + xOffset) / pxPerBeat * TempoMap.tpq).round() + TempoMap.tpq;
    for (final b in project.tempo.barMarksUntil(maxTick)) {
      final x = b.tick / TempoMap.tpq * pxPerBeat - xOffset + keyW;
      if (x < keyW - 40 || x > size.width + 40) continue;
      canvas.drawLine(Offset(x, 0), Offset(x, size.height),
          Paint()..color = th.gridBar..strokeWidth = 1.2);
      tp.text = TextSpan(text: '${b.index + 1}', style: TextStyle(color: th.dim, fontSize: 9));
      tp.layout();
      tp.paint(canvas, Offset(x + 3, 1));
    }
    for (final s in project.tempo.segs) {
      final x = s.tick / TempoMap.tpq * pxPerBeat - xOffset + keyW;
      if (x < keyW - 80 || x > size.width) continue;
      final rect = Rect.fromLTWH(x + 2, size.height - 13, 44, 11);
      canvas.drawRRect(RRect.fromRectAndRadius(rect, const Radius.circular(3)),
          Paint()..color = th.primary.withAlpha(40));
      tp.text = TextSpan(
          text: '${s.bpm % 1 == 0 ? s.bpm.toStringAsFixed(0) : s.bpm.toStringAsFixed(2)}',
          style: TextStyle(color: th.primary, fontSize: 8, fontWeight: FontWeight.w700));
      tp.layout();
      tp.paint(canvas, Offset(rect.left + 2, rect.top + 1));
    }
  }

  @override
  bool shouldRepaint(covariant _RulerPainter old) => true;
}

class _RollPainter extends CustomPainter {
  final XNProject project;
  final XNTheme th;
  final double pxPerBeat, xOffset, topMidi, rowH, keyW;
  final int? selectedId;
  final int playTick;
  final int snapDiv;

  _RollPainter({
    required this.project, required this.th,
    required this.pxPerBeat, required this.xOffset,
    required this.topMidi, required this.rowH, required this.keyW,
    required this.selectedId, required this.playTick, required this.snapDiv,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final fill = Paint();
    // ---- 行背景 ----
    final top = topMidi.floor() + 1;
    final rows = (size.height / rowH).ceil() + 2;
    for (int r = 0; r <= rows; r++) {
      final midi = top - r;
      if (midi < 0) break;
      final y = (topMidi - midi) * rowH;
      fill.color = isBlackKey(midi) ? th.rollBlackRow : th.rollWhiteRow;
      canvas.drawRect(Rect.fromLTWH(0, y, size.width, rowH), fill);
      if (midi % 12 == 0) {
        canvas.drawLine(Offset(0, y + rowH), Offset(size.width, y + rowH),
            Paint()..color = th.gridBeat..strokeWidth = 1);
      }
    }
    // ---- 变拍/变 BPM 网格 ----
    final maxTick = ((size.width - keyW + xOffset) / pxPerBeat * TempoMap.tpq).round() + TempoMap.tpq;
    final sub = TempoMap.tpq ~/ math.max(1, snapDiv);
    for (final b in project.tempo.barMarksUntil(maxTick)) {
      final seg = project.tempo.segAtTick(b.tick);
      final bx = b.tick / TempoMap.tpq * pxPerBeat - xOffset + keyW;
      if (bx > keyW - 40 && bx < size.width + 40) {
        canvas.drawLine(Offset(bx, 0), Offset(bx, size.height),
            Paint()..color = th.gridBar..strokeWidth = 1.6);
      }
      for (int bt = 0; bt < b.beats; bt++) {
        final beatTick = b.tick + bt * seg.beatTicks;
        if (bt > 0) {
          final x = beatTick / TempoMap.tpq * pxPerBeat - xOffset + keyW;
          if (x > keyW && x < size.width) {
            canvas.drawLine(Offset(x, 0), Offset(x, size.height),
                Paint()..color = th.gridBeat..strokeWidth = 1);
          }
        }
        for (int s2 = 1; s2 < snapDiv; s2++) {
          final x = (beatTick + s2 * sub) / TempoMap.tpq * pxPerBeat - xOffset + keyW;
          if (x > keyW && x < size.width) {
            canvas.drawLine(Offset(x, 0), Offset(x, size.height),
                Paint()..color = th.gridSub..strokeWidth = 0.6);
          }
        }
      }
    }
    // ---- 音符 ----
    final tp = TextPainter(textDirection: TextDirection.ltr);
    for (final tr in project.tracks) {
      if (tr.muted) continue;
      for (final n in tr.notes) {
        final x1 = n.start / TempoMap.tpq * pxPerBeat - xOffset + keyW;
        final x2 = n.end / TempoMap.tpq * pxPerBeat - xOffset + keyW;
        if (x2 < 0 || x1 > size.width) continue;
        final y = (topMidi - n.pitch) * rowH;
        final rect = Rect.fromLTRB(
            x1.clamp(keyW, size.width), y + 1,
            math.max(x1 + 8, x2).clamp(keyW + 8, size.width), y + rowH - 1);
        final rrect = RRect.fromRectAndRadius(rect, const Radius.circular(4));
        final sel = n.id == selectedId;
        canvas.drawRRect(rrect,
            Paint()..color = Color(tr.colorValue).withAlpha(sel ? 255 : 210));
        if (sel) {
          canvas.drawRRect(rrect, Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 2
            ..color = th.text);
        }
        tp.text = TextSpan(text: n.lyric, style: TextStyle(
            color: th.dark ? Colors.white : Colors.black, fontSize: 10, fontWeight: FontWeight.w600));
        tp.layout();
        if (tp.width < rect.width - 6 && rect.height > 10) {
          tp.paint(canvas, Offset(rect.left + 4, rect.top + 1));
        }
      }
    }
    // ---- 钢琴键列 ----
    for (int r = 0; r <= rows; r++) {
      final midi = top - r;
      if (midi < 0) break;
      final y = (topMidi - midi) * rowH;
      canvas.drawRect(Rect.fromLTWH(0, y, keyW, rowH),
          Paint()..color = isBlackKey(midi) ? th.keyBlack : th.keyWhite);
      canvas.drawLine(Offset(0, y + rowH), Offset(keyW, y + rowH),
          Paint()..color = th.gridSub..strokeWidth = 0.5);
      if (midi % 12 == 0) {
        tp.text = TextSpan(text: 'C${midi ~/ 12 - 1}',
            style: TextStyle(color: th.dark ? Colors.white70 : Colors.white, fontSize: 8, fontWeight: FontWeight.w700));
        tp.layout();
        tp.paint(canvas, Offset(keyW - tp.width - 4, y + rowH - 11));
      }
    }
    canvas.drawLine(Offset(keyW, 0), Offset(keyW, size.height),
        Paint()..color = th.gridBar..strokeWidth = 1.5);
    // ---- 播放游标 ----
    final px = playTick / TempoMap.tpq * pxPerBeat - xOffset + keyW;
    if (px >= 0 && px <= size.width) {
      canvas.drawLine(Offset(px, 0), Offset(px, size.height),
          Paint()..color = th.playhead..strokeWidth = 2);
      canvas.drawCircle(Offset(px, 4), 4, Paint()..color = th.playhead);
    }
  }

  @override
  bool shouldRepaint(covariant _RollPainter old) => true;
}