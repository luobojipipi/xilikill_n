import 'dart:math' as math;
import 'dart:io';
import 'dart:typed_data';

double dclamp(double v, double lo, double hi) => v < lo ? lo : (v > hi ? hi : v);
double smooth01(double x) {
  final v = dclamp(x, 0.0, 1.0);
  return v * v * (3 - 2 * v);
}

/// 双二阶滤波器（RBJ 系数）
class Biquad {
  double _b0 = 1, _b1 = 0, _b2 = 0, _a1 = 0, _a2 = 0;
  double _x1 = 0, _x2 = 0, _y1 = 0, _y2 = 0;
  final double sr;

  Biquad([this.sr = 44100]);

  void reset() { _x1 = _x2 = _y1 = _y2 = 0; }

  void setBandpass(double f, double q) {
    final w0 = 6.283185307179586 * f / sr;
    final cw = math.cos(w0), sw = math.sin(w0);
    final alpha = sw / (2 * math.max(0.3, q));
    final a0 = 1 + alpha;
    _b0 = alpha / a0; _b1 = 0; _b2 = -alpha / a0;
    _a1 = (-2 * cw) / a0; _a2 = (1 - alpha) / a0;
  }

  void setLowpass(double f, double q) {
    final w0 = 6.283185307179586 * math.min(f, sr * 0.45) / sr;
    final cw = math.cos(w0), sw = math.sin(w0);
    final alpha = sw / (2 * math.max(0.3, q));
    final a0 = 1 + alpha;
    _b0 = ((1 - cw) / 2) / a0; _b1 = (1 - cw) / a0; _b2 = _b0;
    _a1 = (-2 * cw) / a0; _a2 = (1 - alpha) / a0;
  }

  double tick(double x) {
    final y = _b0 * x + _b1 * _x1 + _b2 * _x2 - _a1 * _y1 - _a2 * _y2;
    _x2 = _x1; _x1 = x; _y2 = _y1; _y1 = y;
    return y;
  }
}

/// 迭代基-2 FFT
class FFT {
  final int n;
  late final List<int> _rev;
  FFT(this.n) {
    _rev = List<int>.filled(n, 0);
    int bits = 0;
    while ((1 << bits) < n) { bits++; }
    for (int i = 0; i < n; i++) {
      int r = 0;
      for (int b = 0; b < bits; b++) {
        if ((i >> b) & 1 == 1) r |= 1 << (bits - 1 - b);
      }
      _rev[i] = r;
    }
  }

  void transform(Float64List re, Float64List im) {
    for (int i = 0; i < n; i++) {
      final j = _rev[i];
      if (j > i) {
        double t = re[i]; re[i] = re[j]; re[j] = t;
        t = im[i]; im[i] = im[j]; im[j] = t;
      }
    }
    for (int len = 2; len <= n; len <<= 1) {
      final ang = -6.283185307179586 / len;
      final wr = math.cos(ang), wi = math.sin(ang);
      final half = len >> 1;
      for (int i = 0; i < n; i += len) {
        double cr = 1, ci = 0;
        for (int k = 0; k < half; k++) {
          final ur = re[i + k], ui = im[i + k];
          final xr = re[i + k + half], xi = im[i + k + half];
          final vr = xr * cr - xi * ci;
          final vi = xr * ci + xi * cr;
          re[i + k] = ur + vr; im[i + k] = ui + vi;
          re[i + k + half] = ur - vr; im[i + k + half] = ui - vi;
          final ncr = cr * wr - ci * wi;
          ci = cr * wi + ci * wr;
          cr = ncr;
        }
      }
    }
  }
}

/// Float32 单声道 → 16bit PCM WAV
Uint8List encodeWav16(Float32List data, int sampleRate) {
  final bytes = ByteData(44 + data.length * 2);
  void str(int off, String s) {
    for (int i = 0; i < s.length; i++) {
      bytes.setUint8(off + i, s.codeUnitAt(i));
    }
  }
  str(0, 'RIFF');
  bytes.setUint32(4, 36 + data.length * 2, Endian.little);
  str(8, 'WAVE');
  str(12, 'fmt ');
  bytes.setUint32(16, 16, Endian.little);
  bytes.setUint16(20, 1, Endian.little);
  bytes.setUint16(22, 1, Endian.little);
  bytes.setUint32(24, sampleRate, Endian.little);
  bytes.setUint32(28, sampleRate * 2, Endian.little);
  bytes.setUint16(32, 2, Endian.little);
  bytes.setUint16(34, 16, Endian.little);
  str(36, 'data');
  bytes.setUint32(40, data.length * 2, Endian.little);
  for (int i = 0; i < data.length; i++) {
    final v = dclamp(data[i], -1.0, 1.0);
    bytes.setInt16(44 + i * 2, (v * 32767).round(), Endian.little);
  }
  return bytes.buffer.asUint8List();
}

/// 读取 WAV（PCM8/16/24/32、float32），混合为单声道，返回 (数据, 采样率)
(Float32List, int)? readWavMonoSync(String path) {
  try {
    final bytes = File(path).readAsBytesSync();
    if (bytes.length < 44) return null;
    if (bytes[0] != 0x52 || bytes[1] != 0x49 || bytes[2] != 0x46 || bytes[3] != 0x46) return null;
    final bd = ByteData.sublistView(bytes);
    int p = 12;
    int fmt = 1, ch = 1, sr = 44100, bits = 16;
    int dataStart = -1, dataLen = 0;
    while (p + 8 <= bytes.length) {
      final id = String.fromCharCodes(bytes.sublist(p, p + 4));
      final sz = bd.getUint32(p + 4, Endian.little);
      if (id == 'fmt ' && p + 24 <= bytes.length) {
        fmt = bd.getUint16(p + 8, Endian.little);
        ch = bd.getUint16(p + 10, Endian.little);
        sr = bd.getUint32(p + 12, Endian.little);
        bits = bd.getUint16(p + 22, Endian.little);
      } else if (id == 'data') {
        dataStart = p + 8;
        dataLen = math.min(sz, bytes.length - p - 8);
        break;
      }
      p += 8 + sz + (sz & 1);
    }
    if (dataStart < 0 || dataLen <= 0 || bits < 8) return null;
    final frame = bits ~/ 8;
    final n = dataLen ~/ frame;
    if (n <= 0) return null;
    final out = Float32List(n);
    for (int i = 0; i < n; i++) {
      final o = dataStart + i * frame;
      double v = 0;
      if (fmt == 3 && bits == 32) {
        v = bd.getFloat32(o, Endian.little);
      } else if (bits == 16) {
        v = bd.getInt16(o, Endian.little) / 32768.0;
      } else if (bits == 8) {
        v = (bd.getUint8(o) - 128) / 128.0;
      } else if (bits == 24) {
        final x = bd.getUint8(o) | (bd.getUint8(o + 1) << 8) | (bd.getInt8(o + 2) << 16);
        v = x / 8388608.0;
      } else if (bits == 32) {
        v = bd.getInt32(o, Endian.little) / 2147483648.0;
      }
      out[i] = v;
    }
    if (ch > 1) {
      final m = Float32List(n ~/ ch);
      for (int i = 0; i < m.length; i++) {
        double s = 0;
        for (int c = 0; c < ch; c++) { s += out[i * ch + c]; }
        m[i] = s / ch;
      }
      return (m, sr);
    }
    return (out, sr);
  } catch (_) {
    return null;
  }
}

/// 从波形提取共振峰（汉宁窗 + FFT + 峰值拾取），返回 [F1,F2,F3,F4]
List<double>? extractFormants(Float32List mono, int sr) {
  const target = 22050;
  final ratio = sr / target;
  final nIn = math.min(mono.length, (0.35 * sr).round());
  final outN = (nIn / ratio).round();
  if (outN < 2048 || mono.length < 1024) return null;
  final res = Float32List(outN);
  for (int i = 0; i < outN; i++) {
    final x = i * ratio;
    final i0 = x.floor();
    final f = x - i0;
    final a = mono[math.min(i0, mono.length - 1)];
    final b = mono[math.min(i0 + 1, mono.length - 1)];
    res[i] = a + (b - a) * f;
  }
  final w = math.min(res.length, 4096);
  if (w < 1024) return null;
  final start = (res.length - w) ~/ 2;
  double mean = 0;
  for (int i = 0; i < w; i++) { mean += res[start + i]; }
  mean /= w;
  final re = Float64List(w), im = Float64List(w);
  for (int i = 0; i < w; i++) {
    final hann = 0.5 - 0.5 * math.cos(2 * math.pi * i / (w - 1));
    re[i] = (res[start + i] - mean) * hann;
  }
  FFT(w).transform(re, im);
  final bins = w >> 1;
  final mag = Float64List(bins);
  double mx = 0;
  for (int i = 0; i < bins; i++) {
    mag[i] = math.sqrt(re[i] * re[i] + im[i] * im[i]);
    if (mag[i] > mx) mx = mag[i];
  }
  if (mx <= 0) return null;
  final peaks = <MapEntry<double, double>>[];
  final binHz = target / w;
  for (int i = 2; i < bins - 2; i++) {
    final f = i * binHz;
    if (f < 150 || f > 5200) continue;
    if (mag[i] > mag[i - 1] && mag[i] >= mag[i + 1] && mag[i] > mx * 0.08) {
      peaks.add(MapEntry(f, mag[i]));
    }
  }
  peaks.sort((a, b) => b.value.compareTo(a.value));
  final chosen = <double>[];
  for (final pk in peaks) {
    if (chosen.length >= 4) break;
    var ok = true;
    for (final c in chosen) {
      if ((c - pk.key).abs() < 250) { ok = false; break; }
    }
    if (ok) chosen.add(pk.key);
  }
  if (chosen.length < 3) return null;
  chosen.sort();
  while (chosen.length < 4) {
    chosen.add(chosen.last * 1.35 + 300);
  }
  return chosen.sublist(0, 4);
}